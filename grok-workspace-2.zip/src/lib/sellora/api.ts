import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import { isReservedSlug, randsToCents, slugify } from "@/lib/sellora/format";
import { planById, type PlanId } from "@/lib/sellora/plans";

/**
 * Sellora data access.
 *
 * Photos live in Postgres (`image_data` / `logo_data`) because the deployed
 * app cannot keep files on disk. `/api/media/*` serves them. Swap that column
 * for object storage later without changing the shop UI.
 *
 * Subscriptions record the chosen plan. `payment_provider` stays `test` until
 * a PayFast or Yoco webhook writes `provider_ref` and sets status to `active`.
 * Limits already read `plan`, so billing does not require a UI rewrite.
 */

export type Billing = {
  plan: PlanId;
  planName: string;
  priceZar: number;
  status: string;
  paymentProvider: string;
  trialEndsAt: string | null;
  storeLimit: number;
  productLimit: number;
};

export type StoreCard = {
  id: string;
  name: string;
  slug: string;
  city: string;
  status: string;
  productCount: number;
  orderCount: number;
  attentionCount: number;
};

export type HomeData = {
  billing: Billing;
  stores: StoreCard[];
  totals: { products: number; openOrders: number; attention: number };
};

export type BankDetails = {
  bankName: string;
  accountHolder: string;
  accountNumber: string;
  branchCode: string;
};

export type PublicStore = {
  name: string;
  slug: string;
  tagline: string;
  description: string;
  city: string;
  whatsapp: string;
  email: string;
  logo: string | null;
  sample: boolean;
  pickupNote: string;
  bank: BankDetails | null;
};

export type Product = {
  id: string;
  name: string;
  slug: string;
  description: string;
  priceCents: number;
  compareCents: number | null;
  stock: number;
  sku: string;
  status: "active" | "draft";
  image: string | null;
};

export type StoreAdmin = PublicStore & {
  id: string;
  status: "live" | "draft";
};

export type OrderItem = {
  id: string;
  productId: string | null;
  name: string;
  qty: number;
  unitCents: number;
};

export type OrderRecord = {
  id: string;
  number: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerCity: string;
  address: string;
  notes: string;
  paymentMethod: string;
  status: string;
  subtotalCents: number;
  createdAt: string;
  items: OrderItem[];
};

export type Workspace = {
  billing: Billing;
  store: StoreAdmin;
  products: Product[];
  orders: OrderRecord[];
};

export type PublicOrder = {
  number: string;
  status: string;
  paymentMethod: string;
  subtotalCents: number;
  createdAt: string;
  customerName: string;
  items: OrderItem[];
  bank: BankDetails | null;
  pickupNote: string;
  storeName: string;
  slug: string;
};

type Result<T> = { ok: true; data: T } | { ok: false; message: string };

function fail(message: string): Result<never> {
  return { ok: false, message };
}

function text(value: unknown, max: number): string {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function stamp(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return value == null ? "" : String(value);
}

function num(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function validImage(data: string): boolean {
  if (data.length > 280_000) return false;
  return (
    data.startsWith("data:image/jpeg;base64,") ||
    data.startsWith("data:image/png;base64,") ||
    data.startsWith("data:image/webp;base64,")
  );
}

function flag(value: unknown): boolean {
  return value === true || value === "t" || value === "true" || value === 1;
}

function productImage(row: { id: string; image_path: string | null; has_image: boolean }): string | null {
  if (row.image_path) return row.image_path;
  if (flag(row.has_image)) return `/api/media/product/${row.id}`;
  return null;
}

function bankFrom(row: {
  bank_name: string;
  account_holder: string;
  account_number: string;
  branch_code: string;
}): BankDetails | null {
  if (!row.bank_name && !row.account_number) return null;
  return {
    bankName: row.bank_name,
    accountHolder: row.account_holder,
    accountNumber: row.account_number,
    branchCode: row.branch_code,
  };
}

type StoreRow = {
  id: string;
  user_id: string;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  city: string;
  whatsapp: string;
  email: string;
  status: string;
  bank_name: string;
  account_holder: string;
  account_number: string;
  branch_code: string;
  pickup_note: string;
  has_logo: boolean;
};

function toPublicStore(row: StoreRow): PublicStore {
  return {
    name: row.name,
    slug: row.slug,
    tagline: row.tagline,
    description: row.description,
    city: row.city,
    whatsapp: row.whatsapp,
    email: row.email,
    logo: flag(row.has_logo) ? `/api/media/store/${row.id}` : null,
    sample: row.user_id === "showcase",
    pickupNote: row.pickup_note,
    bank: bankFrom(row),
  };
}

type ProductRow = {
  id: string;
  name: string;
  slug: string;
  description: string;
  price_cents: number;
  compare_cents: number | null;
  stock: number;
  sku: string;
  status: string;
  image_path: string | null;
  has_image: boolean;
};

function toProduct(row: ProductRow): Product {
  const status = row.status === "draft" ? "draft" : "active";
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    priceCents: num(row.price_cents),
    compareCents: row.compare_cents == null ? null : num(row.compare_cents),
    stock: num(row.stock),
    sku: row.sku,
    status,
    image: productImage(row),
  };
}

const STORE_FIELDS = `
  id, user_id, name, slug, tagline, description, city, whatsapp, email, status,
  bank_name, account_holder, account_number, branch_code, pickup_note,
  (logo_data is not null) as has_logo
`;

const PRODUCT_FIELDS = `
  id, name, slug, description, price_cents, compare_cents, stock, sku, status,
  image_path, (image_data is not null) as has_image
`;

type SubRow = {
  plan: string;
  status: string;
  payment_provider: string;
  trial_ends_at: unknown;
};

async function ensureSub(sql: Sql, userId: string): Promise<Billing> {
  await sql`
    insert into subscriptions (user_id, plan, status, payment_provider, trial_ends_at)
    values (${userId}, 'starter', 'trial', 'test', now() + interval '14 days')
    on conflict (user_id) do nothing
  `;
  const rows = await sql<SubRow>`
    select plan, status, payment_provider, trial_ends_at
    from subscriptions where user_id = ${userId}
  `;
  const row = rows[0];
  const plan = planById(row?.plan ?? "starter");
  return {
    plan: plan.id,
    planName: plan.name,
    priceZar: plan.priceZar,
    status: row?.status ?? "trial",
    paymentProvider: row?.payment_provider ?? "test",
    trialEndsAt: row?.trial_ends_at ? stamp(row.trial_ends_at) : null,
    storeLimit: plan.stores,
    productLimit: plan.products,
  };
}

async function selectStore(sql: Sql, where: string, params: unknown[]): Promise<StoreRow | null> {
  const rows = await sql.query<StoreRow>(`select ${STORE_FIELDS} from stores where ${where}`, params);
  return rows[0] ?? null;
}

async function selectProducts(sql: Sql, where: string, params: unknown[]): Promise<ProductRow[]> {
  return sql.query<ProductRow>(
    `select ${PRODUCT_FIELDS} from products where ${where} order by created_at desc`,
    params,
  );
}

function orderNumber(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  let value = "SL-";
  for (const byte of bytes) value += alphabet[byte % alphabet.length];
  return value;
}

type OrderRow = {
  id: string;
  public_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  customer_city: string;
  address: string;
  notes: string;
  payment_method: string;
  status: string;
  subtotal_cents: number;
  created_at: unknown;
};

type ItemRow = {
  id: string;
  order_id: string;
  product_id: string | null;
  name: string;
  qty: number;
  unit_cents: number;
};

function toOrder(row: OrderRow, items: ItemRow[]): OrderRecord {
  return {
    id: row.id,
    number: row.public_number,
    customerName: row.customer_name,
    customerEmail: row.customer_email,
    customerPhone: row.customer_phone,
    customerCity: row.customer_city,
    address: row.address,
    notes: row.notes,
    paymentMethod: row.payment_method,
    status: row.status,
    subtotalCents: num(row.subtotal_cents),
    createdAt: stamp(row.created_at),
    items: items.map((item) => ({
      id: item.id,
      productId: item.product_id,
      name: item.name,
      qty: num(item.qty),
      unitCents: num(item.unit_cents),
    })),
  };
}

async function ordersForStore(sql: Sql, storeId: string): Promise<OrderRecord[]> {
  const rows = await sql<OrderRow>`
    select id, public_number, customer_name, customer_email, customer_phone, customer_city,
           address, notes, payment_method, status, subtotal_cents, created_at
    from orders where store_id = ${storeId}
    order by created_at desc
    limit 100
  `;
  if (rows.length === 0) return [];
  const params: unknown[] = [];
  const slots = rows.map((row, index) => {
    params.push(row.id);
    return `$${index + 1}`;
  });
  const items = await sql.query<ItemRow>(
    `select id, order_id, product_id, name, qty, unit_cents from order_items where order_id in (${slots.join(",")})`,
    params,
  );
  return rows.map((row) => toOrder(row, items.filter((item) => item.order_id === row.id)));
}

export const getPublicStorefront = createServerFn({ method: "GET" })
  .validator((input: { slug?: string }) => ({ slug: text(input?.slug, 40) }))
  .handler(async ({ data }): Promise<{ store: PublicStore; products: Product[] } | null> => {
    if (!data.slug) return null;
    const sql = await getSql();
    const store = await selectStore(sql, "slug = $1 and status = 'live'", [data.slug]);
    if (!store) return null;
    const products = await selectProducts(sql, "store_id = $1 and status = 'active'", [store.id]);
    return { store: toPublicStore(store), products: products.map(toProduct) };
  });

export const getPublicProduct = createServerFn({ method: "GET" })
  .validator((input: { slug?: string; productSlug?: string }) => ({
    slug: text(input?.slug, 40),
    productSlug: text(input?.productSlug, 60),
  }))
  .handler(async ({ data }): Promise<{ store: PublicStore; product: Product } | null> => {
    const sql = await getSql();
    const store = await selectStore(sql, "slug = $1 and status = 'live'", [data.slug]);
    if (!store) return null;
    const products = await selectProducts(
      sql,
      "store_id = $1 and slug = $2 and status = 'active'",
      [store.id, data.productSlug],
    );
    const product = products[0];
    if (!product) return null;
    return { store: toPublicStore(store), product: toProduct(product) };
  });

export const getPublicOrder = createServerFn({ method: "GET" })
  .validator((input: { slug?: string; number?: string }) => ({
    slug: text(input?.slug, 40),
    number: text(input?.number, 20).toUpperCase(),
  }))
  .handler(async ({ data }): Promise<PublicOrder | null> => {
    const sql = await getSql();
    const store = await selectStore(sql, "slug = $1", [data.slug]);
    if (!store) return null;
    const rows = await sql<OrderRow>`
      select id, public_number, customer_name, customer_email, customer_phone, customer_city,
             address, notes, payment_method, status, subtotal_cents, created_at
      from orders where store_id = ${store.id} and public_number = ${data.number}
    `;
    const row = rows[0];
    if (!row) return null;
    const items = await sql<ItemRow>`
      select id, order_id, product_id, name, qty, unit_cents
      from order_items where order_id = ${row.id}
    `;
    const order = toOrder(row, items);
    return {
      number: order.number,
      status: order.status,
      paymentMethod: order.paymentMethod,
      subtotalCents: order.subtotalCents,
      createdAt: order.createdAt,
      customerName: order.customerName,
      items: order.items,
      bank: order.paymentMethod === "eft" ? bankFrom(store) : null,
      pickupNote: order.paymentMethod === "collection" ? store.pickup_note : "",
      storeName: store.name,
      slug: store.slug,
    };
  });

type PlaceInput = {
  slug?: string;
  items?: { productId?: string; qty?: number }[];
  customer?: {
    name?: string;
    email?: string;
    phone?: string;
    city?: string;
    address?: string;
    notes?: string;
  };
  paymentMethod?: string;
};

export const placeOrder = createServerFn({ method: "POST" })
  .validator((input: PlaceInput) => input)
  .handler(async ({ data }): Promise<Result<{ number: string }>> => {
    const slug = text(data?.slug, 40);
    const name = text(data?.customer?.name, 80);
    const email = text(data?.customer?.email, 120);
    const phone = text(data?.customer?.phone, 30);
    const city = text(data?.customer?.city, 80);
    const address = text(data?.customer?.address, 240);
    const notes = text(data?.customer?.notes, 400);
    const paymentMethod = data?.paymentMethod === "collection" ? "collection" : data?.paymentMethod === "eft" ? "eft" : "";
    if (!slug) return fail("Choose a shop.");
    if (name.length < 2) return fail("Add the customer name.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Add a valid email address.");
    if (!paymentMethod) return fail("Choose how this order will be paid.");
    const rawItems = Array.isArray(data?.items) ? data.items : [];
    const merged = new Map<string, number>();
    for (const item of rawItems) {
      const id = text(item?.productId, 80);
      const qty = Math.floor(num(item?.qty));
      if (!id || qty < 1 || qty > 99) continue;
      merged.set(id, Math.min(99, (merged.get(id) ?? 0) + qty));
    }
    if (merged.size === 0) return fail("Your bag is empty.");
    if (merged.size > 30) return fail("Too many different products in one order.");

    const sql = await getSql();
    const store = await selectStore(sql, "slug = $1 and status = 'live'", [slug]);
    if (!store) return fail("This shop is not taking orders.");

    const ids = [...merged.keys()];
    const params: unknown[] = [store.id, ...ids];
    const slots = ids.map((_, index) => `$${index + 2}`);
    const products = await sql.query<{
      id: string;
      name: string;
      price_cents: number;
      stock: number;
      status: string;
    }>(
      `select id, name, price_cents, stock, status from products where store_id = $1 and id in (${slots.join(",")})`,
      params,
    );
    const byId = new Map(products.map((product) => [product.id, product]));
    const lines: { id: string; name: string; qty: number; unit: number }[] = [];
    for (const [id, qty] of merged) {
      const product = byId.get(id);
      if (!product || product.status !== "active") return fail("A product in your bag is no longer available.");
      if (num(product.stock) < qty) return fail(`${product.name} only has ${num(product.stock)} in stock.`);
      lines.push({ id, name: product.name, qty, unit: num(product.price_cents) });
    }

    const decremented: { id: string; qty: number }[] = [];
    let createdOrderId: string | null = null;
    try {
      for (const line of lines) {
        const updated = await sql<{ id: string }>`
          update products
          set stock = stock - ${line.qty}, updated_at = now()
          where id = ${line.id} and store_id = ${store.id} and status = 'active' and stock >= ${line.qty}
          returning id
        `;
        if (updated.length === 0) throw new Error(`${line.name} just sold out. Adjust the quantity and try again.`);
        decremented.push({ id: line.id, qty: line.qty });
      }
      const subtotal = lines.reduce((sum, line) => sum + line.qty * line.unit, 0);
      const id = crypto.randomUUID();
      let number = orderNumber();
      for (let attempt = 0; attempt < 3; attempt += 1) {
        const clash = await sql<{ id: string }>`select id from orders where public_number = ${number}`;
        if (clash.length === 0) break;
        number = orderNumber();
      }
      await sql`
        insert into orders (
          id, store_id, user_id, public_number, customer_name, customer_email, customer_phone,
          customer_city, address, notes, payment_method, status, subtotal_cents
        ) values (
          ${id}, ${store.id}, ${store.user_id}, ${number}, ${name}, ${email}, ${phone},
          ${city}, ${address}, ${notes}, ${paymentMethod}, 'new', ${subtotal}
        )
      `;
      createdOrderId = id;
      for (const line of lines) {
        await sql`
          insert into order_items (id, order_id, product_id, name, qty, unit_cents)
          values (${crypto.randomUUID()}, ${id}, ${line.id}, ${line.name}, ${line.qty}, ${line.unit})
        `;
      }
      return { ok: true, data: { number } };
    } catch (error) {
      if (createdOrderId) await sql`delete from orders where id = ${createdOrderId}`;
      for (const entry of decremented) {
        await sql`update products set stock = stock + ${entry.qty}, updated_at = now() where id = ${entry.id}`;
      }
      return fail(error instanceof Error ? error.message : "Could not place the order.");
    }
  });

export const getHome = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<HomeData> => {
    const sql = await getSql();
    const billing = await ensureSub(sql, context.userId);
    const rows = await sql<{
      id: string;
      name: string;
      slug: string;
      city: string;
      status: string;
      product_count: number;
      order_count: number;
      attention_count: number;
    }>`
      select s.id, s.name, s.slug, s.city, s.status,
        (select count(*) from products p where p.store_id = s.id) as product_count,
        (select count(*) from orders o where o.store_id = s.id and o.status <> 'cancelled') as order_count,
        (select count(*) from products p where p.store_id = s.id and p.status = 'active' and p.stock <= 3) as attention_count
      from stores s
      where s.user_id = ${context.userId}
      order by s.created_at desc
    `;
    const stores: StoreCard[] = rows.map((row) => ({
      id: row.id,
      name: row.name,
      slug: row.slug,
      city: row.city,
      status: row.status,
      productCount: num(row.product_count),
      orderCount: num(row.order_count),
      attentionCount: num(row.attention_count),
    }));
    return {
      billing,
      stores,
      totals: {
        products: stores.reduce((sum, store) => sum + store.productCount, 0),
        openOrders: stores.reduce((sum, store) => sum + store.orderCount, 0),
        attention: stores.reduce((sum, store) => sum + store.attentionCount, 0),
      },
    };
  });

type CreateStoreInput = { name?: string; slug?: string; city?: string; tagline?: string; publish?: boolean };

export const createStore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: CreateStoreInput) => input)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const name = text(data?.name, 80);
    const slug = slugify(text(data?.slug, 40) || name);
    const city = text(data?.city, 80);
    const tagline = text(data?.tagline, 140);
    if (name.length < 2) return fail("Give the shop a name.");
    if (slug.length < 3 || isReservedSlug(slug)) return fail("Choose a longer, simpler link name.");
    const sql = await getSql();
    const billing = await ensureSub(sql, context.userId);
    const counts = await sql<{ n: number }>`select count(*) as n from stores where user_id = ${context.userId}`;
    if (num(counts[0]?.n) >= billing.storeLimit) {
      return fail(`${billing.planName} includes ${billing.storeLimit} store${billing.storeLimit === 1 ? "" : "s"}. Change plan on Billing to add another.`);
    }
    const taken = await sql<{ id: string }>`select id from stores where slug = ${slug}`;
    if (taken.length > 0) return fail("That shop link is already taken.");
    const id = crypto.randomUUID();
    const status = data?.publish === false ? "draft" : "live";
    await sql`
      insert into stores (id, user_id, name, slug, tagline, city, status)
      values (${id}, ${context.userId}, ${name}, ${slug}, ${tagline}, ${city}, ${status})
    `;
    return { ok: true, data: { id } };
  });

export const getWorkspace = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((input: { storeId?: string }) => ({ storeId: text(input?.storeId, 80) }))
  .handler(async ({ context, data }): Promise<Workspace | null> => {
    const sql = await getSql();
    const billing = await ensureSub(sql, context.userId);
    const store = await selectStore(sql, "id = $1 and user_id = $2", [data.storeId, context.userId]);
    if (!store) return null;
    const products = await selectProducts(sql, "store_id = $1 and user_id = $2", [store.id, context.userId]);
    const orders = await ordersForStore(sql, store.id);
    const admin: StoreAdmin = {
      ...toPublicStore(store),
      id: store.id,
      status: store.status === "draft" ? "draft" : "live",
    };
    return { billing, store: admin, products: products.map(toProduct), orders };
  });

type UpdateStoreInput = {
  storeId?: string;
  name?: string;
  slug?: string;
  tagline?: string;
  description?: string;
  city?: string;
  whatsapp?: string;
  email?: string;
  status?: string;
  bankName?: string;
  accountHolder?: string;
  accountNumber?: string;
  branchCode?: string;
  pickupNote?: string;
  logoData?: string | null;
};

export const updateStore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: UpdateStoreInput) => input)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const storeId = text(data?.storeId, 80);
    const name = text(data?.name, 80);
    const slug = slugify(text(data?.slug, 40));
    const email = text(data?.email, 120);
    const whatsapp = text(data?.whatsapp, 20).replace(/\D/g, "");
    const status = data?.status === "draft" ? "draft" : "live";
    if (name.length < 2) return fail("The shop needs a name.");
    if (slug.length < 3 || isReservedSlug(slug)) return fail("That link name will not work.");
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("That email does not look right.");
    if (whatsapp && (whatsapp.length < 8 || whatsapp.length > 15)) return fail("Enter a WhatsApp number with country code, digits only.");
    if (typeof data?.logoData === "string" && data.logoData && !validImage(data.logoData)) {
      return fail("The logo must be a small JPEG, PNG, or WebP.");
    }
    const sql = await getSql();
    const existing = await selectStore(sql, "id = $1 and user_id = $2", [storeId, context.userId]);
    if (!existing) return fail("Shop not found.");
    const taken = await sql<{ id: string }>`select id from stores where slug = ${slug} and id <> ${storeId}`;
    if (taken.length > 0) return fail("That shop link is already taken.");
    await sql`
      update stores set
        name = ${name},
        slug = ${slug},
        tagline = ${text(data?.tagline, 140)},
        description = ${text(data?.description, 800)},
        city = ${text(data?.city, 80)},
        whatsapp = ${whatsapp},
        email = ${email},
        status = ${status},
        bank_name = ${text(data?.bankName, 80)},
        account_holder = ${text(data?.accountHolder, 80)},
        account_number = ${text(data?.accountNumber, 30)},
        branch_code = ${text(data?.branchCode, 12)},
        pickup_note = ${text(data?.pickupNote, 240)},
        updated_at = now()
      where id = ${storeId} and user_id = ${context.userId}
    `;
    if (data?.logoData === null) {
      await sql`update stores set logo_data = null where id = ${storeId} and user_id = ${context.userId}`;
    } else if (typeof data?.logoData === "string" && data.logoData) {
      await sql`update stores set logo_data = ${data.logoData} where id = ${storeId} and user_id = ${context.userId}`;
    }
    return { ok: true, data: { id: storeId } };
  });

export const deleteStore = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { storeId?: string }) => ({ storeId: text(input?.storeId, 80) }))
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const sql = await getSql();
    const removed = await sql<{ id: string }>`
      delete from stores where id = ${data.storeId} and user_id = ${context.userId} returning id
    `;
    if (removed.length === 0) return fail("Shop not found.");
    return { ok: true, data: { id: data.storeId } };
  });

type SaveProductInput = {
  storeId?: string;
  id?: string;
  name?: string;
  description?: string;
  priceRands?: string;
  compareRands?: string;
  stock?: number;
  sku?: string;
  status?: string;
  imageData?: string | null;
};

export const saveProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: SaveProductInput) => input)
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const storeId = text(data?.storeId, 80);
    const name = text(data?.name, 80);
    const description = text(data?.description, 800);
    const sku = text(data?.sku, 40);
    const status = data?.status === "draft" ? "draft" : "active";
    const price = randsToCents(text(data?.priceRands, 16));
    const compareRaw = text(data?.compareRands, 16);
    const compare = compareRaw ? randsToCents(compareRaw) : null;
    const stock = Math.floor(num(data?.stock));
    if (name.length < 2) return fail("Name the product.");
    if (price == null) return fail("Enter a price in rands, such as 99 or 99.50.");
    if (compareRaw && compare == null) return fail("The compare-at price is not a valid amount.");
    if (stock < 0 || stock > 1_000_000) return fail("Stock must be zero or more.");
    if (typeof data?.imageData === "string" && data.imageData && !validImage(data.imageData)) {
      return fail("Use a smaller JPEG, PNG, or WebP.");
    }
    const sql = await getSql();
    const store = await selectStore(sql, "id = $1 and user_id = $2", [storeId, context.userId]);
    if (!store) return fail("Shop not found.");
    const existingId = text(data?.id, 80);
    if (!existingId) {
      const billing = await ensureSub(sql, context.userId);
      const counts = await sql<{ n: number }>`select count(*) as n from products where user_id = ${context.userId}`;
      if (num(counts[0]?.n) >= billing.productLimit) {
        return fail(`${billing.planName} includes ${billing.productLimit} products. Change plan on Billing to add more.`);
      }
    } else {
      const owned = await sql<{ id: string }>`
        select id from products where id = ${existingId} and user_id = ${context.userId} and store_id = ${storeId}
      `;
      if (owned.length === 0) return fail("Product not found.");
    }
    const base = slugify(name) || "product";
    let slug = base;
    for (let n = 2; n < 50; n += 1) {
      const clash = await sql<{ id: string }>`
        select id from products where store_id = ${storeId} and slug = ${slug}
      `;
      if (clash.length === 0 || clash[0]?.id === existingId) break;
      slug = `${base}-${n}`.slice(0, 48);
    }
    const id = existingId || crypto.randomUUID();
    if (!existingId) {
      await sql`
        insert into products (
          id, store_id, user_id, name, slug, description, price_cents, compare_cents, stock, sku, status, image_data
        ) values (
          ${id}, ${storeId}, ${context.userId}, ${name}, ${slug}, ${description}, ${price}, ${compare},
          ${stock}, ${sku}, ${status}, ${typeof data?.imageData === "string" ? data.imageData : null}
        )
      `;
    } else {
      await sql`
        update products set
          name = ${name},
          slug = ${slug},
          description = ${description},
          price_cents = ${price},
          compare_cents = ${compare},
          stock = ${stock},
          sku = ${sku},
          status = ${status},
          updated_at = now()
        where id = ${id} and user_id = ${context.userId}
      `;
      if (data?.imageData === null) {
        await sql`
          update products set image_data = null, image_path = null
          where id = ${id} and user_id = ${context.userId}
        `;
      } else if (typeof data?.imageData === "string" && data.imageData) {
        await sql`
          update products set image_data = ${data.imageData}, image_path = null
          where id = ${id} and user_id = ${context.userId}
        `;
      }
    }
    return { ok: true, data: { id } };
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { productId?: string }) => ({ productId: text(input?.productId, 80) }))
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const sql = await getSql();
    const removed = await sql<{ id: string }>`
      delete from products where id = ${data.productId} and user_id = ${context.userId} returning id
    `;
    if (removed.length === 0) return fail("Product not found.");
    return { ok: true, data: { id: data.productId } };
  });

export const setOrderStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId?: string; status?: string }) => ({
    orderId: text(input?.orderId, 80),
    status: text(input?.status, 20),
  }))
  .handler(async ({ context, data }): Promise<Result<{ id: string }>> => {
    const allowed = new Set(["new", "confirmed", "fulfilled", "cancelled"]);
    if (!allowed.has(data.status)) return fail("Unknown status.");
    const sql = await getSql();
    const rows = await sql<{ id: string; status: string }>`
      select id, status from orders where id = ${data.orderId} and user_id = ${context.userId}
    `;
    const order = rows[0];
    if (!order) return fail("Order not found.");
    if (order.status === "cancelled" && data.status !== "cancelled") {
      return fail("A cancelled order stays cancelled so stock is not sold twice.");
    }
    if (order.status !== "cancelled" && data.status === "cancelled") {
      const items = await sql<{ product_id: string | null; qty: number }>`
        select product_id, qty from order_items where order_id = ${order.id}
      `;
      for (const item of items) {
        if (!item.product_id) continue;
        await sql`
          update products set stock = stock + ${num(item.qty)}, updated_at = now()
          where id = ${item.product_id} and user_id = ${context.userId}
        `;
      }
    }
    await sql`
      update orders set status = ${data.status}
      where id = ${order.id} and user_id = ${context.userId}
    `;
    return { ok: true, data: { id: order.id } };
  });

export const setPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { plan?: string }) => ({ plan: text(input?.plan, 20) }))
  .handler(async ({ context, data }): Promise<Result<Billing>> => {
    const plan = planById(data.plan);
    if (plan.id !== data.plan) return fail("Unknown plan.");
    const sql = await getSql();
    await ensureSub(sql, context.userId);
    await sql`
      update subscriptions
      set plan = ${plan.id}, status = 'trial', payment_provider = 'test', updated_at = now()
      where user_id = ${context.userId}
    `;
    const billing = await ensureSub(sql, context.userId);
    return { ok: true, data: billing };
  });
