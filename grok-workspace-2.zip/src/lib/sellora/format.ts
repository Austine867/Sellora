const RESERVED = new Set([
  "dashboard",
  "login",
  "api",
  "s",
  "billing",
  "admin",
  "app",
  "sellora",
  "pricing",
  "auth",
  "new",
  "www",
  "checkout",
  "order",
]);

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
}

export function isReservedSlug(slug: string): boolean {
  return RESERVED.has(slug);
}

export function formatZar(cents: number): string {
  return new Intl.NumberFormat("en-ZA", {
    style: "currency",
    currency: "ZAR",
    minimumFractionDigits: cents % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

export function randsToCents(raw: string): number | null {
  const t = raw.trim().replace(/\s/g, "").replace(/^R/i, "").replace(/,/g, "");
  if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
  const [whole, frac = ""] = t.split(".");
  const cents = Number(whole) * 100 + Number((frac + "00").slice(0, 2));
  if (!Number.isInteger(cents) || cents < 0 || cents > 10_000_000) return null;
  return cents;
}

export function centsToRandsInput(cents: number): string {
  const whole = Math.floor(cents / 100);
  const frac = cents % 100;
  return frac === 0 ? String(whole) : `${whole}.${String(frac).padStart(2, "0")}`;
}

export function formatWhen(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en-ZA", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function paymentLabel(method: string): string {
  if (method === "eft") return "EFT";
  if (method === "collection") return "Pay on collection";
  return method;
}

export function orderStatusLabel(status: string): string {
  if (status === "new") return "New";
  if (status === "confirmed") return "Confirmed";
  if (status === "fulfilled") return "Fulfilled";
  if (status === "cancelled") return "Cancelled";
  return status;
}
