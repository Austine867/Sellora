import { create } from "zustand";
import { persist } from "zustand/middleware";

export type CartItem = {
  productId: string;
  name: string;
  priceCents: number;
  qty: number;
  image: string | null;
};

type CartState = {
  carts: Record<string, CartItem[]>;
  add: (slug: string, item: Omit<CartItem, "qty">, qty?: number) => void;
  setQty: (slug: string, productId: string, qty: number) => void;
  clear: (slug: string) => void;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      carts: {},
      add: (slug, item, qty = 1) => {
        const current = get().carts[slug] ?? [];
        const existing = current.find((entry) => entry.productId === item.productId);
        const next = existing
          ? current.map((entry) =>
              entry.productId === item.productId
                ? { ...entry, qty: Math.min(99, entry.qty + qty), priceCents: item.priceCents }
                : entry,
            )
          : [...current, { ...item, qty }];
        set({ carts: { ...get().carts, [slug]: next } });
      },
      setQty: (slug, productId, qty) => {
        const current = get().carts[slug] ?? [];
        const next =
          qty <= 0
            ? current.filter((entry) => entry.productId !== productId)
            : current.map((entry) => (entry.productId === productId ? { ...entry, qty } : entry));
        set({ carts: { ...get().carts, [slug]: next } });
      },
      clear: (slug) => {
        const carts = { ...get().carts };
        delete carts[slug];
        set({ carts });
      },
    }),
    { name: "sellora-cart" },
  ),
);

export function cartCount(items: CartItem[] | undefined): number {
  return (items ?? []).reduce((sum, item) => sum + item.qty, 0);
}

export function cartTotal(items: CartItem[] | undefined): number {
  return (items ?? []).reduce((sum, item) => sum + item.qty * item.priceCents, 0);
}
