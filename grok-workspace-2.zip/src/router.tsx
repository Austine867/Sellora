import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { previewPathRewrite } from "@/lib/preview-path-prefix";
import { routeTree } from "./routeTree.gen";
import { Link } from "@tanstack/react-router";

export function getRouter() {
  return createRouter({
    routeTree,
    rewrite: previewPathRewrite(),
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
  });
}

function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-background px-6 text-center text-foreground">
      <div className="max-w-md">
        <p className="text-sm text-muted-foreground">404</p>
        <h1 className="mt-2 font-display text-4xl text-foreground">This page is not on the shelf.</h1>
        <p className="mt-3 text-muted-foreground">The link may be old, or the shop may have been unpublished.</p>
        <Link
          to="/"
          className="mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          Back to Sellora
        </Link>
      </div>
    </main>
  );
}
