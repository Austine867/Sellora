import { Link, createFileRoute } from "@tanstack/react-router";
import { ProductVisual } from "@/components/sellora/product-visual";
import { MissingShop, StoreChrome } from "@/components/sellora/store-chrome";
import { getPublicStorefront } from "@/lib/sellora/api";
import { formatZar } from "@/lib/sellora/format";

export const Route = createFileRoute("/s/$slug/")({
  loader: async ({ params }) => getPublicStorefront({ data: { slug: params.slug } }),
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData?.store ? `${loaderData.store.name} · Sellora` : "Shop · Sellora" }],
  }),
  component: ShopPage,
});

function ShopPage() {
  const data = Route.useLoaderData();
  if (!data) return <MissingShop />;
  const { store, products } = data;

  return (
    <StoreChrome store={store}>
      <div className="max-w-2xl">
        {store.logo ? (
          <img src={store.logo} alt="" className="mb-4 size-16 rounded-lg object-cover" />
        ) : null}
        <h1 className="font-display text-4xl sm:text-5xl">{store.name}</h1>
        {store.tagline ? <p className="mt-3 text-lg text-muted-foreground">{store.tagline}</p> : null}
        {store.description ? <p className="mt-3 text-muted-foreground">{store.description}</p> : null}
        {store.whatsapp ? (
          <a
            className="mt-4 inline-flex h-11 items-center text-sm font-medium underline"
            href={`https://wa.me/${store.whatsapp}`}
            target="_blank"
            rel="noreferrer"
          >
            WhatsApp the shop
          </a>
        ) : null}
      </div>
      {products.length === 0 ? (
        <p className="mt-10 text-muted-foreground">Nothing is on the shelf yet.</p>
      ) : (
        <ul className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-3">
          {products.map((product) => (
            <li key={product.id}>
              <Link to="/s/$slug/p/$productSlug" params={{ slug: store.slug, productSlug: product.slug }}>
                <div className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
                  <ProductVisual name={product.name} image={product.image} className="aspect-square" />
                </div>
                <div className="mt-3 flex items-baseline justify-between gap-2">
                  <p className="font-medium">{product.name}</p>
                  <p className="shrink-0 text-sm tabular-nums">{formatZar(product.priceCents)}</p>
                </div>
                <p className="text-sm text-muted-foreground">{product.stock > 0 ? `${product.stock} in stock` : "Sold out"}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </StoreChrome>
  );
}
