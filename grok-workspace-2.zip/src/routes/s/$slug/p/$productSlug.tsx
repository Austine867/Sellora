import { useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ProductVisual } from "@/components/sellora/product-visual";
import { MissingShop, StoreChrome } from "@/components/sellora/store-chrome";
import { getPublicProduct } from "@/lib/sellora/api";
import { useCart } from "@/lib/sellora/cart";
import { formatZar } from "@/lib/sellora/format";

export const Route = createFileRoute("/s/$slug/p/$productSlug")({
  loader: ({ params }) => getPublicProduct({ data: { slug: params.slug, productSlug: params.productSlug } }),
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData?.product
          ? `${loaderData.product.name} · ${loaderData.store.name}`
          : "Product · Sellora",
      },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const data = Route.useLoaderData();
  const add = useCart((state) => state.add);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  if (!data) return <MissingShop />;
  const { store, product } = data;
  const max = Math.max(0, Math.min(99, product.stock));

  return (
    <StoreChrome store={store}>
      <Link to="/s/$slug" params={{ slug: store.slug }} className="text-sm text-muted-foreground">
        Back to {store.name}
      </Link>
      <div className="mt-4 grid gap-8 lg:grid-cols-2">
        <div className="overflow-hidden rounded-2xl bg-card ring-1 ring-foreground/10">
          <ProductVisual name={product.name} image={product.image} labelled className="aspect-square" />
        </div>
        <div>
          <h1 className="font-display text-4xl">{product.name}</h1>
          <p className="mt-3 flex items-baseline gap-3">
            <span className="font-display text-3xl tabular-nums">{formatZar(product.priceCents)}</span>
            {product.compareCents && product.compareCents > product.priceCents ? (
              <span className="text-muted-foreground line-through tabular-nums">{formatZar(product.compareCents)}</span>
            ) : null}
          </p>
          {product.sku ? <p className="mt-2 text-sm text-muted-foreground">SKU {product.sku}</p> : null}
          {product.description ? <p className="mt-4 text-muted-foreground">{product.description}</p> : null}
          <p className="mt-4 text-sm">{max > 0 ? `${product.stock} in stock` : "Sold out"}</p>
          {max > 0 ? (
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <label className="text-sm font-medium">
                Qty
                <input
                  className="ml-2 h-11 w-16 rounded-md border border-border bg-card px-2 text-center tabular-nums"
                  inputMode="numeric"
                  value={qty}
                  onChange={(event) => {
                    const next = Math.floor(Number(event.target.value));
                    if (!Number.isFinite(next)) return;
                    setQty(Math.min(max, Math.max(1, next)));
                  }}
                />
              </label>
              <Button
                size="lg"
                onClick={() => {
                  add(
                    store.slug,
                    {
                      productId: product.id,
                      name: product.name,
                      priceCents: product.priceCents,
                      image: product.image,
                    },
                    qty,
                  );
                  setAdded(true);
                }}
              >
                Add to bag
              </Button>
              {added ? (
                <Link to="/s/$slug/checkout" params={{ slug: store.slug }} className="text-sm underline">
                  Go to checkout
                </Link>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </StoreChrome>
  );
}
