import { useEffect, useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MissingShop, StoreChrome } from "@/components/sellora/store-chrome";
import { ProductVisual } from "@/components/sellora/product-visual";
import { getPublicStorefront, placeOrder } from "@/lib/sellora/api";
import { cartTotal, useCart } from "@/lib/sellora/cart";
import { formatZar } from "@/lib/sellora/format";

export const Route = createFileRoute("/s/$slug/checkout")({
  loader: ({ params }) => getPublicStorefront({ data: { slug: params.slug } }),
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData?.store ? `Checkout · ${loaderData.store.name}` : "Checkout · Sellora" }],
  }),
  component: CheckoutPage,
});

function CheckoutPage() {
  const data = Route.useLoaderData();
  const navigate = useNavigate();
  const slug = data?.store.slug ?? "";
  const items = useCart((state) => state.carts[slug]);
  const setQty = useCart((state) => state.setQty);
  const clear = useCart((state) => state.clear);
  const [ready, setReady] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [method, setMethod] = useState<"eft" | "collection">("eft");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => setReady(true), []);

  if (!data) return <MissingShop />;
  const { store } = data;
  const lines = ready ? (items ?? []) : [];
  const total = cartTotal(lines);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    const result = await placeOrder({
      data: {
        slug: store.slug,
        items: lines.map((line) => ({ productId: line.productId, qty: line.qty })),
        customer: { name, email, phone, city, address, notes },
        paymentMethod: method,
      },
    });
    setPending(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    clear(store.slug);
    void navigate({
      to: "/s/$slug/order/$number",
      params: { slug: store.slug, number: result.data.number },
    });
  }

  return (
    <StoreChrome store={store}>
      <h1 className="font-display text-4xl">Checkout</h1>
      <p className="mt-2 text-muted-foreground">The shop confirms the price and stock when you place the order. Card payments are not taken here yet.</p>
      {lines.length === 0 ? (
        <div className="mt-8">
          <p>Your bag is empty.</p>
          <Link to="/s/$slug" params={{ slug: store.slug }} className="mt-4 inline-block text-sm underline">
            Continue browsing
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_320px]">
          <form className="space-y-4" onSubmit={onSubmit}>
            <label className="block text-sm font-medium">
              Name
              <Input className="mt-1.5" value={name} onChange={(event) => setName(event.target.value)} required autoComplete="name" />
            </label>
            <label className="block text-sm font-medium">
              Email
              <Input className="mt-1.5" type="email" value={email} onChange={(event) => setEmail(event.target.value)} required autoComplete="email" />
            </label>
            <label className="block text-sm font-medium">
              Mobile
              <Input className="mt-1.5" value={phone} onChange={(event) => setPhone(event.target.value)} autoComplete="tel" />
            </label>
            <label className="block text-sm font-medium">
              City
              <Input className="mt-1.5" value={city} onChange={(event) => setCity(event.target.value)} />
            </label>
            <label className="block text-sm font-medium">
              Address or collection note
              <Textarea className="mt-1.5" value={address} onChange={(event) => setAddress(event.target.value)} />
            </label>
            <label className="block text-sm font-medium">
              Note to the shop
              <Textarea className="mt-1.5" value={notes} onChange={(event) => setNotes(event.target.value)} />
            </label>
            <fieldset className="space-y-2">
              <legend className="text-sm font-medium">How you will pay</legend>
              <label className="flex min-h-11 items-center gap-3 text-sm">
                <input type="radio" name="pay" checked={method === "eft"} onChange={() => setMethod("eft")} />
                EFT — the shop’s banking details are on the confirmation
              </label>
              <label className="flex min-h-11 items-center gap-3 text-sm">
                <input type="radio" name="pay" checked={method === "collection"} onChange={() => setMethod("collection")} />
                Pay on collection
              </label>
            </fieldset>
            {method === "eft" && store.bank ? (
              <div className="rounded-xl bg-secondary p-4 text-sm">
                <p className="font-medium">Pay to</p>
                <p className="mt-1">{store.bank.bankName}</p>
                <p>{store.bank.accountHolder}</p>
                <p className="tabular-nums">{store.bank.accountNumber}</p>
                {store.bank.branchCode ? <p>Branch {store.bank.branchCode}</p> : null}
                <p className="mt-2 text-muted-foreground">Use your order number as the payment reference.</p>
              </div>
            ) : null}
            {method === "collection" && store.pickupNote ? (
              <p className="rounded-xl bg-secondary p-4 text-sm">{store.pickupNote}</p>
            ) : null}
            {error ? <p className="text-sm text-danger">{error}</p> : null}
            <Button type="submit" size="lg" disabled={pending}>
              {pending ? "Placing order…" : `Place order · ${formatZar(total)}`}
            </Button>
          </form>
          <aside className="h-fit rounded-2xl bg-card p-4 ring-1 ring-foreground/10">
            <h2 className="font-display text-2xl">Bag</h2>
            <ul className="mt-4 space-y-4">
              {lines.map((line) => (
                <li key={line.productId} className="flex gap-3">
                  <div className="size-16 shrink-0 overflow-hidden rounded-md">
                    <ProductVisual name={line.name} image={line.image} className="size-16" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{line.name}</p>
                    <p className="text-sm tabular-nums text-muted-foreground">{formatZar(line.priceCents)}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <button type="button" className="inline-flex size-8 items-center justify-center rounded-md bg-secondary" onClick={() => setQty(store.slug, line.productId, line.qty - 1)} aria-label="Decrease quantity">
                        −
                      </button>
                      <span className="w-6 text-center text-sm tabular-nums">{line.qty}</span>
                      <button type="button" className="inline-flex size-8 items-center justify-center rounded-md bg-secondary" onClick={() => setQty(store.slug, line.productId, line.qty + 1)} aria-label="Increase quantity">
                        +
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <p className="mt-4 flex justify-between text-sm font-medium">
              <span>Total</span>
              <span className="tabular-nums">{formatZar(total)}</span>
            </p>
          </aside>
        </div>
      )}
    </StoreChrome>
  );
}
