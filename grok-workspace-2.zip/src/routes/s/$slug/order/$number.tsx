import { Link, createFileRoute } from "@tanstack/react-router";
import { MissingShop } from "@/components/sellora/store-chrome";
import { getPublicOrder } from "@/lib/sellora/api";
import { formatWhen, formatZar, orderStatusLabel, paymentLabel } from "@/lib/sellora/format";

export const Route = createFileRoute("/s/$slug/order/$number")({
  loader: ({ params }) => getPublicOrder({ data: { slug: params.slug, number: params.number } }),
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData ? `Order ${loaderData.number}` : "Order · Sellora" }],
  }),
  component: OrderPage,
});

function OrderPage() {
  const order = Route.useLoaderData();
  if (!order) return <MissingShop />;

  return (
    <main className="min-h-screen bg-background">
      <div className="mx-auto max-w-lg px-5 py-12">
        <p className="text-sm text-muted-foreground">{order.storeName}</p>
        <h1 className="mt-2 font-display text-4xl">Order {order.number}</h1>
        <p className="mt-3 text-muted-foreground">
          {orderStatusLabel(order.status)} · {paymentLabel(order.paymentMethod)} · {formatWhen(order.createdAt)}
        </p>
        <p className="mt-2 text-sm">Placed by {order.customerName}</p>
        <ul className="mt-6 divide-y divide-border rounded-xl bg-card ring-1 ring-foreground/10">
          {order.items.map((item) => (
            <li key={item.id} className="flex justify-between gap-3 px-4 py-3 text-sm">
              <span>
                {item.qty} × {item.name}
              </span>
              <span className="tabular-nums">{formatZar(item.qty * item.unitCents)}</span>
            </li>
          ))}
          <li className="flex justify-between px-4 py-3 text-sm font-medium">
            <span>Total</span>
            <span className="tabular-nums">{formatZar(order.subtotalCents)}</span>
          </li>
        </ul>
        {order.bank ? (
          <div className="mt-6 rounded-xl bg-secondary p-4 text-sm">
            <p className="font-medium">EFT to</p>
            <p className="mt-2">{order.bank.bankName}</p>
            <p>{order.bank.accountHolder}</p>
            <p className="tabular-nums">{order.bank.accountNumber}</p>
            {order.bank.branchCode ? <p>Branch {order.bank.branchCode}</p> : null}
            <p className="mt-2 text-muted-foreground">Reference: {order.number}</p>
          </div>
        ) : null}
        {order.pickupNote ? <p className="mt-6 rounded-xl bg-secondary p-4 text-sm">{order.pickupNote}</p> : null}
        <Link to="/s/$slug" params={{ slug: order.slug }} className="mt-8 inline-block text-sm underline">
          Back to the shop
        </Link>
      </div>
    </main>
  );
}
