import { Outlet, createFileRoute } from "@tanstack/react-router";
import { DashboardFrame } from "@/components/sellora/dashboard-frame";

export const Route = createFileRoute("/dashboard")({
  component: () => (
    <DashboardFrame>
      <Outlet />
    </DashboardFrame>
  ),
});
