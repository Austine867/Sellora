import { Link, createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/sellora/site";
import { ProductVisual } from "@/components/sellora/product-visual";
import { getPublicStorefront, type Product, type PublicStore } from "@/lib/sellora/api";
import { formatZar } from "@/lib/sellora/format";
import { PLANS } from "@/lib/sellora/plans";

export const Route = createFileRoute("/")({
  loader: async (): Promise<{ store: PublicStore; products: Product[] } | null> => {
    try {
      return await getPublicStorefront({ data: { slug: "cedar-and-salt" } });
    } catch {
      return null;
    }
  },
  component: Home,
});

const STEPS = [
  {
    n: "01",
    title: "Open a shop",
    body: "Register the business, name the store, and publish a link that is yours — not a marketplace listing.",
  },
  {
    n: "02",
    title: "Add what you sell",
    body: "Upload a photo, set a rand price, and keep stock honest. Drafts stay hidden until you are ready.",
  },
  {
    n: "03",
    title: "Take the order",
    body: "Customers check out with EFT or collection. You confirm, pack, and mark it fulfilled.",
  },
];

function Home() {
  const sample = Route.useLoaderData();

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <section className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:py-20 lg:grid-cols-[1.2fr_0.8fr] lg:items-end">
          <div>
            <p className="text-sm font-medium text-muted-foreground">For South African makers and small businesses</p>
            <h1 className="mt-4 max-w-xl font-display text-5xl leading-tight text-foreground sm:text-6xl">
              Your shop, under your own link.
            </h1>
            <p className="mt-5 max-w-lg text-lg text-muted-foreground">
              Sellora is where you put products, stock, and customer orders — then send people a link. From R99 a
              month. No marketplace taking the relationship.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/login"
                className="inline-flex h-12 items-center justify-center rounded-lg bg-primary px-5 text-sm font-medium text-primary-foreground"
              >
                Start a store
              </Link>
              <Link
                to="/s/$slug"
                params={{ slug: "cedar-and-salt" }}
                className="inline-flex h-12 items-center justify-center rounded-lg bg-secondary px-5 text-sm font-medium text-secondary-foreground"
              >
                View a live shop
              </Link>
            </div>
          </div>
          <aside className="rounded-2xl bg-card p-2 ring-1 ring-foreground/10">
            <div className="rounded-xl bg-secondary p-5">
              <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">A shop link</p>
              <p className="mt-3 font-display text-3xl">sellora / cedar-and-salt</p>
              <dl className="mt-6 grid grid-cols-3 gap-3 text-sm">
                <div>
                  <dt className="text-muted-foreground">From</dt>
                  <dd className="mt-1 font-medium tabular-nums">R99</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Currency</dt>
                  <dd className="mt-1 font-medium">ZAR</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Checkout</dt>
                  <dd className="mt-1 font-medium">EFT</dd>
                </div>
              </dl>
            </div>
          </aside>
        </section>

        <section id="how" className="border-t border-border">
          <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:grid-cols-3">
            {STEPS.map((step) => (
              <article key={step.n}>
                <p className="font-display text-2xl text-muted-foreground">{step.n}</p>
                <h2 className="mt-3 font-display text-3xl">{step.title}</h2>
                <p className="mt-3 text-muted-foreground">{step.body}</p>
              </article>
            ))}
          </div>
        </section>

        {sample ? (
          <section className="border-t border-border">
            <div className="mx-auto max-w-6xl px-5 py-14">
              <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
                <div>
                  <p className="text-sm text-muted-foreground">{sample.store.city}</p>
                  <h2 className="mt-1 font-display text-4xl">{sample.store.name}</h2>
                  <p className="mt-2 max-w-lg text-muted-foreground">{sample.store.tagline}</p>
                </div>
                <Link to="/s/$slug" params={{ slug: sample.store.slug }} className="text-sm font-medium underline">
                  Open the shop
                </Link>
              </div>
              <ul className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
                {sample.products.map((product) => (
                  <li key={product.id}>
                    <Link to="/s/$slug/p/$productSlug" params={{ slug: sample.store.slug, productSlug: product.slug }}>
                      <div className="overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10">
                        <ProductVisual name={product.name} image={product.image} className="aspect-square" />
                      </div>
                      <p className="mt-3 text-sm font-medium">{product.name}</p>
                      <p className="text-sm tabular-nums text-muted-foreground">{formatZar(product.priceCents)}</p>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </section>
        ) : null}

        <section id="pricing" className="border-t border-border">
          <div className="mx-auto max-w-6xl px-5 py-14">
            <h2 className="font-display text-4xl">Monthly, from R99.</h2>
            <p className="mt-3 max-w-xl text-muted-foreground">
              Pick a plan when you open the workspace. Card payments are not connected yet — test mode will not charge
              you. PayFast or Yoco can sit on the same plan limits later.
            </p>
            <div className="mt-8 grid gap-4 lg:grid-cols-3">
              {PLANS.map((plan) => (
                <article
                  key={plan.id}
                  className={
                    plan.id === "starter"
                      ? "rounded-2xl bg-card p-6 ring-2 ring-foreground"
                      : "rounded-2xl bg-card p-6 ring-1 ring-foreground/10"
                  }
                >
                  <p className="text-sm text-muted-foreground">{plan.name}</p>
                  <p className="mt-3 font-display text-4xl tabular-nums">
                    R{plan.priceZar}
                    <span className="font-sans text-base text-muted-foreground"> / month</span>
                  </p>
                  <p className="mt-3 text-sm text-muted-foreground">{plan.blurb}</p>
                  <ul className="mt-5 space-y-2 text-sm">
                    {plan.features.map((feature) => (
                      <li key={feature}>{feature}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
            <Link
              to="/login"
              className="mt-8 inline-flex h-12 items-center rounded-lg bg-primary px-5 text-sm font-medium text-primary-foreground"
            >
              Create an account
            </Link>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
