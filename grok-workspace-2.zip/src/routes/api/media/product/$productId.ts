import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";

function imageResponse(data: string | null): Response {
  if (!data) return new Response("Not found", { status: 404 });
  const comma = data.indexOf(",");
  if (comma < 0 || !data.startsWith("data:image/")) return new Response("Not found", { status: 404 });
  const mime = data.slice(5, comma).split(";")[0]?.toLowerCase() ?? "";
  if (mime !== "image/jpeg" && mime !== "image/png" && mime !== "image/webp") {
    return new Response("Not found", { status: 404 });
  }
  const bytes = Buffer.from(data.slice(comma + 1), "base64");
  return new Response(bytes, {
    headers: {
      "Content-Type": mime,
      "Cache-Control": "public, max-age=86400",
    },
  });
}

export const Route = createFileRoute("/api/media/product/$productId")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const sql = await getSql();
        const rows = await sql<{ image_data: string | null }>`
          select image_data from products where id = ${params.productId}
        `;
        return imageResponse(rows[0]?.image_data ?? null);
      },
    },
  },
});
