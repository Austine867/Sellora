import { useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { createStore } from "@/lib/sellora/api";
import { slugify } from "@/lib/sellora/format";

export const Route = createFileRoute("/dashboard/new")({
  component: NewStorePage,
});

function NewStorePage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [slugTouched, setSlugTouched] = useState(false);
  const [city, setCity] = useState("");
  const [tagline, setTagline] = useState("");
  const [publish, setPublish] = useState(true);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    const result = await createStore({
      data: { name, slug: slug || slugify(name), city, tagline, publish },
    });
    setPending(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    void navigate({
      to: "/dashboard/stores/$storeId",
      params: { storeId: result.data.id },
      search: { tab: "products", edit: "new" },
    });
  }

  return (
    <div className="mx-auto max-w-lg">
      <Link to="/dashboard" className="text-sm text-muted-foreground">
        Back to stores
      </Link>
      <h1 className="mt-3 font-display text-4xl">New store</h1>
      <p className="mt-2 text-muted-foreground">This becomes the public link customers open.</p>
      <form className="mt-8 space-y-4" onSubmit={onSubmit}>
        <label className="block text-sm font-medium">
          Store name
          <Input
            className="mt-1.5"
            value={name}
            onChange={(event) => {
              setName(event.target.value);
              if (!slugTouched) setSlug(slugify(event.target.value));
            }}
            required
            placeholder="Harbour Goods"
          />
        </label>
        <label className="block text-sm font-medium">
          Link
          <div className="mt-1.5 flex items-center gap-2">
            <span className="text-sm text-muted-foreground">/s/</span>
            <Input
              value={slug}
              onChange={(event) => {
                setSlugTouched(true);
                setSlug(slugify(event.target.value));
              }}
              required
              placeholder="harbour-goods"
            />
          </div>
        </label>
        <label className="block text-sm font-medium">
          City
          <Input className="mt-1.5" value={city} onChange={(event) => setCity(event.target.value)} placeholder="Durban" />
        </label>
        <label className="block text-sm font-medium">
          Short line
          <Input
            className="mt-1.5"
            value={tagline}
            onChange={(event) => setTagline(event.target.value)}
            placeholder="What you sell, in one sentence"
          />
        </label>
        <label className="flex items-center gap-3 text-sm">
          <input type="checkbox" checked={publish} onChange={(event) => setPublish(event.target.checked)} className="size-4" />
          Publish now, so the link works immediately
        </label>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button type="submit" disabled={pending}>
          {pending ? "Creating…" : "Create store"}
        </Button>
      </form>
    </div>
  );
}
