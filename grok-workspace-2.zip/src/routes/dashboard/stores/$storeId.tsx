import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { StoreWorkspace } from "@/components/sellora/workspace";

type StoreSearch = {
  tab: "products" | "orders" | "settings";
  edit?: string;
};

export const Route = createFileRoute("/dashboard/stores/$storeId")({
  validateSearch: (search: Record<string, unknown>): StoreSearch => {
    const tab = search.tab === "orders" || search.tab === "settings" ? search.tab : "products";
    const edit = typeof search.edit === "string" && search.edit.length > 0 ? search.edit : undefined;
    return edit ? { tab, edit } : { tab };
  },
  component: StoreRoute,
});

function StoreRoute() {
  const { storeId } = Route.useParams();
  const { tab, edit } = Route.useSearch();
  const navigate = useNavigate();

  return (
    <StoreWorkspace
      storeId={storeId}
      tab={tab}
      edit={edit}
      onTab={(next) => {
        void navigate({
          to: "/dashboard/stores/$storeId",
          params: { storeId },
          search: { tab: next },
        });
      }}
      onEdit={(next) => {
        void navigate({
          to: "/dashboard/stores/$storeId",
          params: { storeId },
          search: next ? { tab: "products", edit: next } : { tab: "products" },
        });
      }}
    />
  );
}
