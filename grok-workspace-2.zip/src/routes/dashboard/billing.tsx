import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { getHome, setPlan, type Billing } from "@/lib/sellora/api";
import { formatWhen } from "@/lib/sellora/format";
import { PLANS, type PlanId } from "@/lib/sellora/plans";

export const Route = createFileRoute("/dashboard/billing")({
  component: BillingPage,
});

function BillingPage() {
  const [billing, setBilling] = useState<Billing | null>(null);
  const [error, setError] = useState("");
  const [pending, setPending] = useState<PlanId | null>(null);

  useEffect(() => {
    let cancelled = false;
    getHome()
      .then((home) => {
        if (!cancelled) setBilling(home.billing);
      })
      .catch((caught: unknown) => {
        if (!cancelled) setError(caught instanceof Error ? caught.message : "Could not load billing.");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function choose(plan: PlanId) {
    setPending(plan);
    setError("");
    const result = await setPlan({ data: { plan } });
    setPending(null);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    setBilling(result.data);
  }

  return (
    <div>
      <h1 className="font-display text-4xl">Billing</h1>
      <p className="mt-2 max-w-xl text-muted-foreground">
        Plans start at R99 a month. Payments run in test mode: choosing a plan sets your limits and does not charge a
        card. When PayFast or Yoco is connected, a webhook will confirm the payment before a plan is marked paid.
      </p>
      {billing ? (
        <p className="mt-4 text-sm">
          Current plan: <span className="font-medium">{billing.planName}</span>
          {billing.trialEndsAt ? ` · trial noted until ${formatWhen(billing.trialEndsAt)}` : ""}
          {" · "}
          provider: {billing.paymentProvider}
        </p>
      ) : (
        <div className="mt-6 h-8 w-64 animate-pulse rounded-md bg-muted" />
      )}
      {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}
      <div className="mt-8 grid gap-4 lg:grid-cols-3">
        {PLANS.map((plan) => {
          const current = billing?.plan === plan.id;
          return (
            <article key={plan.id} className="flex flex-col rounded-2xl bg-card p-6 ring-1 ring-foreground/10">
              <p className="text-sm text-muted-foreground">{plan.name}</p>
              <p className="mt-2 font-display text-4xl tabular-nums">
                R{plan.priceZar}
                <span className="font-sans text-base text-muted-foreground"> / month</span>
              </p>
              <p className="mt-3 text-sm text-muted-foreground">{plan.blurb}</p>
              <ul className="mt-4 flex-1 space-y-2 text-sm">
                {plan.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <Button className="mt-6" variant={current ? "secondary" : "primary"} disabled={current || pending !== null} onClick={() => choose(plan.id)}>
                {current ? "Current plan" : pending === plan.id ? "Saving…" : "Use this plan"}
              </Button>
            </article>
          );
        })}
      </div>
    </div>
  );
}
