import { useEffect, useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { getHome, type HomeData } from "@/lib/sellora/api";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/dashboard/")({
  component: DashboardHome,
});

function DashboardHome() {
  const user = useCurrentUser();
  const [data, setData] = useState<HomeData | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    getHome()
      .then((result) => {
        if (!cancelled) setData(result);
      })
      .catch((caught: unknown) => {
        if (!cancelled) setError(caught instanceof Error ? caught.message : "Could not load your stores.");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const first = user?.displayName?.split(" ")[0];

  return (
    <div>
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <h1 className="font-display text-4xl">{first ? `${first}, your stores` : "Your stores"}</h1>
          <p className="mt-2 text-muted-foreground">
            {data
              ? `${data.billing.planName} · R${data.billing.priceZar}/month · ${data.billing.paymentProvider === "test" ? "test mode, no charge" : data.billing.status}`
              : "Loading the workspace…"}
          </p>
        </div>
        <Link
          to="/dashboard/new"
          className="inline-flex h-11 items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          New store
        </Link>
      </div>
      {error ? <p className="mt-6 text-sm text-danger">{error}</p> : null}
      {data ? (
        <dl className="mt-8 grid grid-cols-3 gap-3">
          <Stat label="Products" value={data.totals.products} />
          <Stat label="Orders" value={data.totals.openOrders} />
          <Stat label="Low stock" value={data.totals.attention} />
        </dl>
      ) : (
        <div className="mt-8 h-20 animate-pulse rounded-xl bg-muted" />
      )}
      <div className="mt-8 grid gap-4">
        {data && data.stores.length === 0 ? (
          <div className="rounded-2xl bg-card p-8 ring-1 ring-foreground/10">
            <h2 className="font-display text-3xl">No store yet</h2>
            <p className="mt-2 max-w-md text-muted-foreground">
              Name it, publish the link, then add the first product. Customers can order as soon as the shop is live.
            </p>
            <Link
              to="/dashboard/new"
              className="mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
            >
              Create a store
            </Link>
          </div>
        ) : null}
        {data?.stores.map((store) => (
          <Link
            key={store.id}
            to="/dashboard/stores/$storeId"
            params={{ storeId: store.id }}
            search={{ tab: "products" }}
            className="rounded-2xl bg-card p-5 ring-1 ring-foreground/10"
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="font-display text-2xl">{store.name}</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  /s/{store.slug}
                  {store.city ? ` · ${store.city}` : ""}
                </p>
              </div>
              <Badge tone={store.status === "live" ? "ok" : "warn"}>{store.status === "live" ? "Live" : "Draft"}</Badge>
            </div>
            <p className="mt-4 text-sm tabular-nums text-muted-foreground">
              {store.productCount} products · {store.orderCount} orders
              {store.attentionCount > 0 ? ` · ${store.attentionCount} need stock` : ""}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-display text-3xl tabular-nums">{value}</dd>
    </div>
  );
}
