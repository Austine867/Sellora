import { useState } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mark } from "@/components/sellora/site";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

const BEARER_KEY = "grok-auth.bearer-token";

function rememberToken(response: Response) {
  const token = response.headers.get("set-auth-token");
  if (!token) return;
  try {
    sessionStorage.setItem(BEARER_KEY, token);
  } catch {
    /* storage unavailable */
  }
}

function LoginPage() {
  const [mode, setMode] = useState<"in" | "up">("up");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    if (password.length < 8) {
      setError("Use at least 8 characters.");
      return;
    }
    setPending(true);
    try {
      if (mode === "up") {
        if (name.trim().length < 2) {
          setError("Add the name of the person who will run the shop.");
          setPending(false);
          return;
        }
        const result = await authClient.signUp.email({
          name: name.trim(),
          email: email.trim(),
          password,
          callbackURL: "/dashboard",
          fetchOptions: { onSuccess: (ctx) => rememberToken(ctx.response) },
        });
        if (result.error) {
          setError(result.error.message ?? "Could not create the account.");
          setPending(false);
          return;
        }
      } else {
        const result = await authClient.signIn.email({
          email: email.trim(),
          password,
          callbackURL: "/dashboard",
          fetchOptions: { onSuccess: (ctx) => rememberToken(ctx.response) },
        });
        if (result.error) {
          setError(result.error.message ?? "Those details did not match.");
          setPending(false);
          return;
        }
      }
      window.location.assign("/dashboard");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Sign-in failed.");
      setPending(false);
    }
  }

  return (
    <main className="grid min-h-screen bg-background lg:grid-cols-2">
      <section className="flex flex-col px-5 py-6 sm:px-10">
        <Link to="/" className="flex items-center gap-2 text-foreground">
          <Mark />
          <span className="font-display text-xl">Sellora</span>
        </Link>
        <div className="mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10">
          <h1 className="font-display text-4xl">{mode === "up" ? "Open your workspace" : "Welcome back"}</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {mode === "up"
              ? "Create the account that will own your stores. You can invite a card later."
              : "Sign in to manage products, stock, and orders."}
          </p>
          {authEnabled ? (
            <form className="mt-8 space-y-4" onSubmit={onSubmit}>
              {mode === "up" ? (
                <label className="block text-sm font-medium">
                  Your name
                  <Input className="mt-1.5" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" required />
                </label>
              ) : null}
              <label className="block text-sm font-medium">
                Email
                <Input
                  className="mt-1.5"
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  autoComplete="email"
                  required
                />
              </label>
              <label className="block text-sm font-medium">
                Password
                <Input
                  className="mt-1.5"
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  autoComplete={mode === "up" ? "new-password" : "current-password"}
                  required
                  minLength={8}
                />
              </label>
              {error ? <p className="text-sm text-danger">{error}</p> : null}
              <Button type="submit" className="w-full" size="lg" disabled={pending}>
                {pending ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"}
              </Button>
              <button
                type="button"
                className="text-sm text-muted-foreground underline"
                onClick={() => {
                  setMode(mode === "up" ? "in" : "up");
                  setError("");
                }}
              >
                {mode === "up" ? "I already have an account" : "Create an account"}
              </button>
            </form>
          ) : (
            <p className="mt-8 text-sm text-muted-foreground">Sign-in is disabled.</p>
          )}
          <div className="mt-8 space-y-2">
            <p className="text-xs text-muted-foreground">Or continue with</p>
            {GROK_PROVIDERS.map((provider) => (
              <Button
                key={provider.providerId}
                variant="secondary"
                className="w-full"
                onClick={() => {
                  setError("");
                  void signIn(provider.providerId, { callbackURL: "/dashboard" }).catch((caught: unknown) => {
                    setError(caught instanceof Error ? caught.message : "Sign-in failed.");
                  });
                }}
              >
                Continue with {provider.label}
              </Button>
            ))}
          </div>
        </div>
      </section>
      <aside className="hidden border-l border-border bg-card lg:flex lg:flex-col lg:justify-end lg:p-12">
        <p className="max-w-md font-display text-4xl">A store link you can send on WhatsApp tonight.</p>
        <p className="mt-4 max-w-sm text-muted-foreground">
          Products, stock, and orders stay with your business. Powered by WebDev SA.
        </p>
      </aside>
    </main>
  );
}
