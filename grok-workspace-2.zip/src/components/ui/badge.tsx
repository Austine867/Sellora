import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "neutral",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: "neutral" | "ok" | "warn" | "danger" }) {
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center rounded-full px-2 text-xs font-medium",
        tone === "neutral" && "bg-secondary text-foreground",
        tone === "ok" && "bg-secondary text-ok",
        tone === "warn" && "bg-secondary text-warn",
        tone === "danger" && "bg-secondary text-danger",
        className,
      )}
      {...props}
    />
  );
}
