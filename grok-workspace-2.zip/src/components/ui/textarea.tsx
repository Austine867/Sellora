import type { TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "min-h-28 w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none",
        "placeholder:text-muted-foreground focus:border-foreground",
        className,
      )}
      {...props}
    />
  );
}
