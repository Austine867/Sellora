import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8 text-foreground", className)} aria-hidden>
      <rect width="32" height="32" rx="8" fill="currentColor" />
      <path
        d="M9.5 13c.4-2.4 2.4-4 6.6-4 3.6 0 6.2 1.2 6.2 3.4 0 4.6-12.6 2.2-12.6 7.4 0 2.2 2.4 3.5 6.3 3.5 4.2 0 6.4-1.6 6.6-3.8"
        fill="none"
        stroke="var(--color-primary-foreground)"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function SiteHeader() {
  const { user, isPending } = useCurrentUserState();
  const [open, setOpen] = useState(false);

  return (
    <header className="border-b border-border">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-4">
        <Link to="/" className="flex items-center gap-2 text-foreground" onClick={() => setOpen(false)}>
          <Mark />
          <span className="font-display text-xl leading-none">Sellora</span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground sm:flex">
          <a href="/#how" className="hover:text-foreground">
            How it works
          </a>
          <a href="/#pricing" className="hover:text-foreground">
            Pricing
          </a>
          <Link to="/s/$slug" params={{ slug: "cedar-and-salt" }} className="hover:text-foreground">
            Sample shop
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          {isPending ? (
            <div className="h-11 w-28 animate-pulse rounded-lg bg-muted" />
          ) : user ? (
            <Link
              to="/dashboard"
              className="inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
            >
              Dashboard
            </Link>
          ) : (
            <Link
              to="/login"
              className="inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
            >
              Sign in
            </Link>
          )}
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-lg text-foreground sm:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <nav className="flex flex-col gap-1 border-t border-border px-5 py-3 text-sm sm:hidden">
          <a href="/#how" className="flex h-11 items-center" onClick={() => setOpen(false)}>
            How it works
          </a>
          <a href="/#pricing" className="flex h-11 items-center" onClick={() => setOpen(false)}>
            Pricing
          </a>
          <Link
            to="/s/$slug"
            params={{ slug: "cedar-and-salt" }}
            className="flex h-11 items-center"
            onClick={() => setOpen(false)}
          >
            Sample shop
          </Link>
        </nav>
      ) : null}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 text-foreground">
          <Mark className="size-6" />
          <span className="font-display text-lg">Sellora</span>
        </div>
        <p>Powered by WebDev SA. Shops, stock, and orders for South African businesses.</p>
        <div className="flex gap-4">
          <a href="/#pricing" className="hover:text-foreground">
            Pricing
          </a>
          <Link to="/s/$slug" params={{ slug: "cedar-and-salt" }} className="hover:text-foreground">
            Sample shop
          </Link>
        </div>
      </div>
    </footer>
  );
}
