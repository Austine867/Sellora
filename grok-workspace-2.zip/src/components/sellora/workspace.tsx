import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ProductVisual } from "@/components/sellora/product-visual";
import {
  deleteProduct,
  deleteStore,
  getWorkspace,
  saveProduct,
  setOrderStatus,
  updateStore,
  type OrderRecord,
  type Product,
  type Workspace,
} from "@/lib/sellora/api";
import { centsToRandsInput, formatWhen, formatZar, orderStatusLabel, paymentLabel, slugify } from "@/lib/sellora/format";
import { compressImageFile } from "@/lib/sellora/images";

type Tab = "products" | "orders" | "settings";

const EMPTY_PRODUCT = {
  name: "",
  description: "",
  priceRands: "",
  compareRands: "",
  stock: "0",
  sku: "",
  status: "active" as "active" | "draft",
};

export function StoreWorkspace({
  storeId,
  tab,
  edit,
  onTab,
  onEdit,
}: {
  storeId: string;
  tab: Tab;
  edit?: string;
  onTab: (tab: Tab) => void;
  onEdit: (edit?: string) => void;
}) {
  const [data, setData] = useState<Workspace | null>(null);
  const [missing, setMissing] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [version, setVersion] = useState(0);
  const [query, setQuery] = useState("");
  const [orderFilter, setOrderFilter] = useState("all");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setError("");
    getWorkspace({ data: { storeId } })
      .then((result) => {
        if (cancelled) return;
        if (!result) setMissing(true);
        else setData(result);
      })
      .catch((caught: unknown) => {
        if (!cancelled) setError(caught instanceof Error ? caught.message : "Could not load this store.");
      });
    return () => {
      cancelled = true;
    };
  }, [storeId, version]);

  const link = typeof window !== "undefined" && data ? `${window.location.origin}/s/${data.store.slug}` : "";

  async function copyLink() {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setError("Could not copy the link. Select it from the address bar of the live shop.");
    }
  }

  if (missing) {
    return (
      <div>
        <h1 className="font-display text-4xl">Store not found</h1>
        <Link to="/dashboard" className="mt-4 inline-block text-sm underline">
          Back to stores
        </Link>
      </div>
    );
  }

  if (!data) {
    return <div className="h-40 animate-pulse rounded-2xl bg-muted" />;
  }

  const products = data.products.filter((product) => product.name.toLowerCase().includes(query.trim().toLowerCase()));
  const orders = data.orders.filter((order) => orderFilter === "all" || order.status === orderFilter);

  return (
    <div>
      <Link to="/dashboard" className="text-sm text-muted-foreground">
        All stores
      </Link>
      <div className="mt-3 flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="font-display text-4xl">{data.store.name}</h1>
            <Badge tone={data.store.status === "live" ? "ok" : "warn"}>{data.store.status === "live" ? "Live" : "Draft"}</Badge>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">/s/{data.store.slug}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => void copyLink()}>
            {copied ? "Copied" : "Copy link"}
          </Button>
          {data.store.status === "live" ? (
            <Link
              to="/s/$slug"
              params={{ slug: data.store.slug }}
              className="inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
            >
              Open shop
            </Link>
          ) : null}
          <a
            className="inline-flex h-11 items-center rounded-lg bg-secondary px-4 text-sm font-medium"
            href={`https://wa.me/?text=${encodeURIComponent(`${data.store.name}: ${link || `/s/${data.store.slug}`}`)}`}
            target="_blank"
            rel="noreferrer"
          >
            Share
          </a>
        </div>
      </div>
      {error ? <p className="mt-4 text-sm text-danger">{error}</p> : null}
      {notice ? <p className="mt-4 text-sm text-ok">{notice}</p> : null}
      <div className="mt-6 flex gap-2 overflow-x-auto">
        {(
          [
            ["products", "Products"],
            ["orders", "Orders"],
            ["settings", "Settings"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => onTab(id)}
            className={
              tab === id
                ? "h-10 shrink-0 rounded-lg bg-primary px-4 text-sm text-primary-foreground"
                : "h-10 shrink-0 rounded-lg bg-secondary px-4 text-sm"
            }
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "products" ? (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search products" className="sm:max-w-xs" />
              <Button onClick={() => onEdit("new")}>Add product</Button>
            </div>
            {data.products.length === 0 ? (
              <p className="mt-6 text-sm text-muted-foreground">No products yet. Add one, set the price in rands, and it appears on the shop when it is active.</p>
            ) : (
              <ul className="mt-4 divide-y divide-border rounded-xl bg-card ring-1 ring-foreground/10">
                {products.map((product) => (
                  <li key={product.id} className="flex items-center gap-3 p-3">
                    <div className="size-16 shrink-0 overflow-hidden rounded-md">
                      <ProductVisual name={product.name} image={product.image} className="size-16" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{product.name}</p>
                      <p className="text-sm tabular-nums text-muted-foreground">
                        {formatZar(product.priceCents)} · {product.stock} in stock
                        {product.status === "draft" ? " · draft" : ""}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => onEdit(product.id)}>
                      Edit
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          {edit ? (
            <ProductEditor
              key={edit}
              storeId={storeId}
              product={edit === "new" ? null : (data.products.find((item) => item.id === edit) ?? null)}
              onClose={() => onEdit(undefined)}
              onSaved={(message) => {
                setNotice(message);
                setVersion((value) => value + 1);
                onEdit(undefined);
              }}
            />
          ) : (
            <p className="text-sm text-muted-foreground lg:pt-12">
              {data.billing.planName} allows {data.billing.productLimit} products on this account.
            </p>
          )}
        </div>
      ) : null}

      {tab === "orders" ? (
        <OrdersPanel
          orders={orders}
          filter={orderFilter}
          onFilter={setOrderFilter}
          onChanged={(message) => {
            setNotice(message);
            setVersion((value) => value + 1);
          }}
          onError={setError}
        />
      ) : null}

      {tab === "settings" ? (
        <SettingsPanel
          data={data}
          onSaved={(message) => {
            setNotice(message);
            setVersion((value) => value + 1);
          }}
        />
      ) : null}
    </div>
  );
}

function ProductEditor({
  storeId,
  product,
  onClose,
  onSaved,
}: {
  storeId: string;
  product: Product | null;
  onClose: () => void;
  onSaved: (message: string) => void;
}) {
  const [form, setForm] = useState(() =>
    product
      ? {
          name: product.name,
          description: product.description,
          priceRands: centsToRandsInput(product.priceCents),
          compareRands: product.compareCents != null ? centsToRandsInput(product.compareCents) : "",
          stock: String(product.stock),
          sku: product.sku,
          status: product.status,
        }
      : EMPTY_PRODUCT,
  );
  const [imageData, setImageData] = useState<string | null | undefined>(undefined);
  const [preview, setPreview] = useState<string | null>(product?.image ?? null);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    try {
      const data = await compressImageFile(file);
      setImageData(data);
      setPreview(data);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not use that image.");
    }
  }

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    const result = await saveProduct({
      data: {
        storeId,
        id: product?.id,
        name: form.name,
        description: form.description,
        priceRands: form.priceRands,
        compareRands: form.compareRands,
        stock: Number(form.stock),
        sku: form.sku,
        status: form.status,
        imageData,
      },
    });
    setPending(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    onSaved(product ? "Product updated." : "Product added.");
  }

  async function onDelete() {
    if (!product) return;
    setPending(true);
    const result = await deleteProduct({ data: { productId: product.id } });
    setPending(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    onSaved("Product removed.");
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl bg-card p-4 ring-1 ring-foreground/10">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-2xl">{product ? "Edit product" : "New product"}</h2>
        <Button variant="ghost" size="sm" onClick={onClose}>
          Close
        </Button>
      </div>
      <div className="mt-4 overflow-hidden rounded-lg">
        <ProductVisual name={form.name || "Product"} image={preview} labelled className="aspect-square" />
      </div>
      <label className="mt-4 block text-sm font-medium">
        Photo
        <input
          className="mt-1.5 block w-full text-sm"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={(event) => void onFile(event.target.files?.[0])}
        />
      </label>
      {preview ? (
        <button
          type="button"
          className="mt-2 text-sm text-muted-foreground underline"
          onClick={() => {
            setImageData(null);
            setPreview(null);
          }}
        >
          Remove photo
        </button>
      ) : null}
      <label className="mt-4 block text-sm font-medium">
        Name
        <Input className="mt-1.5" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required />
      </label>
      <label className="mt-4 block text-sm font-medium">
        Description
        <Textarea className="mt-1.5" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
      </label>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <label className="text-sm font-medium">
          Price (R)
          <Input className="mt-1.5" inputMode="decimal" value={form.priceRands} onChange={(event) => setForm({ ...form, priceRands: event.target.value })} required />
        </label>
        <label className="text-sm font-medium">
          Compare (R)
          <Input className="mt-1.5" inputMode="decimal" value={form.compareRands} onChange={(event) => setForm({ ...form, compareRands: event.target.value })} />
        </label>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <label className="text-sm font-medium">
          Stock
          <Input className="mt-1.5" inputMode="numeric" value={form.stock} onChange={(event) => setForm({ ...form, stock: event.target.value })} required />
        </label>
        <label className="text-sm font-medium">
          SKU
          <Input className="mt-1.5" value={form.sku} onChange={(event) => setForm({ ...form, sku: event.target.value })} />
        </label>
      </div>
      <label className="mt-4 block text-sm font-medium">
        Visibility
        <select
          className="mt-1.5 h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
          value={form.status}
          onChange={(event) => setForm({ ...form, status: event.target.value === "draft" ? "draft" : "active" })}
        >
          <option value="active">Active on the shop</option>
          <option value="draft">Draft, hidden</option>
        </select>
      </label>
      {error ? <p className="mt-3 text-sm text-danger">{error}</p> : null}
      <div className="mt-4 flex flex-wrap gap-2">
        <Button type="submit" disabled={pending}>
          {pending ? "Saving…" : "Save product"}
        </Button>
        {product ? (
          <Button variant="danger" disabled={pending} onClick={() => void onDelete()}>
            Delete
          </Button>
        ) : null}
      </div>
    </form>
  );
}

function OrdersPanel({
  orders,
  filter,
  onFilter,
  onChanged,
  onError,
}: {
  orders: OrderRecord[];
  filter: string;
  onFilter: (value: string) => void;
  onChanged: (message: string) => void;
  onError: (message: string) => void;
}) {
  const [pending, setPending] = useState("");
  const filters = ["all", "new", "confirmed", "fulfilled", "cancelled"];

  async function update(orderId: string, status: string) {
    setPending(orderId);
    const result = await setOrderStatus({ data: { orderId, status } });
    setPending("");
    if (!result.ok) {
      onError(result.message);
      return;
    }
    onChanged(status === "cancelled" ? "Order cancelled and stock returned." : "Order updated.");
  }

  return (
    <div className="mt-6">
      <div className="flex gap-2 overflow-x-auto">
        {filters.map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => onFilter(value)}
            className={
              filter === value
                ? "h-9 shrink-0 rounded-full bg-primary px-3 text-sm text-primary-foreground"
                : "h-9 shrink-0 rounded-full bg-secondary px-3 text-sm"
            }
          >
            {value === "all" ? "All" : orderStatusLabel(value)}
          </button>
        ))}
      </div>
      {orders.length === 0 ? (
        <p className="mt-6 text-sm text-muted-foreground">
          No orders in this view. Share the shop link. New orders arrive with the customer’s details and how they chose to pay.
        </p>
      ) : (
        <ul className="mt-4 space-y-3">
          {orders.map((order) => (
            <li key={order.id} className="rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-medium">
                    {order.number} · {order.customerName}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {formatWhen(order.createdAt)} · {paymentLabel(order.paymentMethod)} ·{" "}
                    <span className="tabular-nums">{formatZar(order.subtotalCents)}</span>
                  </p>
                </div>
                <Badge tone={order.status === "cancelled" ? "danger" : order.status === "fulfilled" ? "ok" : "neutral"}>
                  {orderStatusLabel(order.status)}
                </Badge>
              </div>
              <ul className="mt-3 text-sm">
                {order.items.map((item) => (
                  <li key={item.id}>
                    {item.qty} × {item.name}
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-sm">
                <a className="underline" href={`mailto:${order.customerEmail}`}>
                  {order.customerEmail}
                </a>
                {order.customerPhone ? ` · ${order.customerPhone}` : ""}
                {order.customerCity ? ` · ${order.customerCity}` : ""}
              </p>
              {order.address ? <p className="text-sm text-muted-foreground">{order.address}</p> : null}
              {order.notes ? <p className="text-sm text-muted-foreground">{order.notes}</p> : null}
              {order.status !== "cancelled" ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {order.status !== "confirmed" && order.status !== "fulfilled" ? (
                    <Button size="sm" variant="secondary" disabled={pending === order.id} onClick={() => void update(order.id, "confirmed")}>
                      Confirm
                    </Button>
                  ) : null}
                  {order.status !== "fulfilled" ? (
                    <Button size="sm" variant="secondary" disabled={pending === order.id} onClick={() => void update(order.id, "fulfilled")}>
                      Mark fulfilled
                    </Button>
                  ) : null}
                  <Button size="sm" variant="danger" disabled={pending === order.id} onClick={() => void update(order.id, "cancelled")}>
                    Cancel
                  </Button>
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function SettingsPanel({ data, onSaved }: { data: Workspace; onSaved: (message: string) => void }) {
  const store = data.store;
  const [form, setForm] = useState({
    name: store.name,
    slug: store.slug,
    tagline: store.tagline,
    description: store.description,
    city: store.city,
    whatsapp: store.whatsapp,
    email: store.email,
    status: store.status,
    bankName: store.bank?.bankName ?? "",
    accountHolder: store.bank?.accountHolder ?? "",
    accountNumber: store.bank?.accountNumber ?? "",
    branchCode: store.bank?.branchCode ?? "",
    pickupNote: store.pickupNote,
  });
  const [logoData, setLogoData] = useState<string | null | undefined>(undefined);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    setForm({
      name: store.name,
      slug: store.slug,
      tagline: store.tagline,
      description: store.description,
      city: store.city,
      whatsapp: store.whatsapp,
      email: store.email,
      status: store.status,
      bankName: store.bank?.bankName ?? "",
      accountHolder: store.bank?.accountHolder ?? "",
      accountNumber: store.bank?.accountNumber ?? "",
      branchCode: store.bank?.branchCode ?? "",
      pickupNote: store.pickupNote,
    });
  }, [store]);

  const logo = useMemo(() => (logoData === null ? null : logoData || store.logo), [logoData, store.logo]);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    const result = await updateStore({
      data: { storeId: store.id, ...form, slug: slugify(form.slug), logoData },
    });
    setPending(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    setLogoData(undefined);
    onSaved("Store settings saved.");
  }

  async function onDelete() {
    setPending(true);
    const result = await deleteStore({ data: { storeId: store.id } });
    setPending(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    window.location.assign("/dashboard");
  }

  return (
    <form onSubmit={onSubmit} className="mt-6 max-w-xl space-y-4">
      <div className="flex items-center gap-3">
        <div className="size-16 overflow-hidden rounded-lg">
          <ProductVisual name={form.name || store.name} image={logo} className="size-16" />
        </div>
        <label className="text-sm font-medium">
          Logo
          <input
            className="mt-1.5 block text-sm"
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (!file) return;
              void compressImageFile(file)
                .then((dataUrl) => setLogoData(dataUrl))
                .catch((caught: unknown) => setError(caught instanceof Error ? caught.message : "Could not use that logo."));
            }}
          />
        </label>
      </div>
      <label className="block text-sm font-medium">
        Name
        <Input className="mt-1.5" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
      </label>
      <label className="block text-sm font-medium">
        Link
        <Input className="mt-1.5" value={form.slug} onChange={(event) => setForm({ ...form, slug: event.target.value })} />
      </label>
      <label className="block text-sm font-medium">
        Tagline
        <Input className="mt-1.5" value={form.tagline} onChange={(event) => setForm({ ...form, tagline: event.target.value })} />
      </label>
      <label className="block text-sm font-medium">
        About the shop
        <Textarea className="mt-1.5" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
      </label>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-sm font-medium">
          City
          <Input className="mt-1.5" value={form.city} onChange={(event) => setForm({ ...form, city: event.target.value })} />
        </label>
        <label className="text-sm font-medium">
          Email
          <Input className="mt-1.5" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} />
        </label>
      </div>
      <label className="block text-sm font-medium">
        WhatsApp (country code, digits)
        <Input className="mt-1.5" value={form.whatsapp} onChange={(event) => setForm({ ...form, whatsapp: event.target.value })} placeholder="27821234567" />
      </label>
      <label className="block text-sm font-medium">
        Visibility
        <select
          className="mt-1.5 h-11 w-full rounded-md border border-border bg-card px-3 text-sm"
          value={form.status}
          onChange={(event) => setForm({ ...form, status: event.target.value === "draft" ? "draft" : "live" })}
        >
          <option value="live">Live</option>
          <option value="draft">Draft — link returns not published</option>
        </select>
      </label>
      <fieldset className="space-y-3 rounded-xl bg-secondary p-4">
        <legend className="px-1 text-sm font-medium">EFT details shown at checkout</legend>
        <Input value={form.bankName} onChange={(event) => setForm({ ...form, bankName: event.target.value })} placeholder="Bank" />
        <Input value={form.accountHolder} onChange={(event) => setForm({ ...form, accountHolder: event.target.value })} placeholder="Account holder" />
        <div className="grid grid-cols-2 gap-3">
          <Input value={form.accountNumber} onChange={(event) => setForm({ ...form, accountNumber: event.target.value })} placeholder="Account number" />
          <Input value={form.branchCode} onChange={(event) => setForm({ ...form, branchCode: event.target.value })} placeholder="Branch code" />
        </div>
      </fieldset>
      <label className="block text-sm font-medium">
        Collection note
        <Textarea className="mt-1.5" value={form.pickupNote} onChange={(event) => setForm({ ...form, pickupNote: event.target.value })} />
      </label>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Button type="submit" disabled={pending}>
        {pending ? "Saving…" : "Save settings"}
      </Button>
      <div className="border-t border-border pt-4">
        {confirmDelete ? (
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm text-danger">Delete this store, its products, and its orders?</p>
            <Button variant="danger" disabled={pending} onClick={() => void onDelete()}>
              Delete store
            </Button>
            <Button variant="ghost" onClick={() => setConfirmDelete(false)}>
              Keep it
            </Button>
          </div>
        ) : (
          <Button variant="danger" onClick={() => setConfirmDelete(true)}>
            Delete store
          </Button>
        )}
      </div>
    </form>
  );
}
