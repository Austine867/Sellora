import { useState } from "react";
import { cn } from "@/lib/utils";

export function ProductVisual({
  name,
  image,
  className,
  labelled = false,
}: {
  name: string;
  image: string | null;
  className?: string;
  labelled?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  if (!image || failed) {
    return (
      <div className={cn("grid place-items-center bg-muted text-foreground", className)} aria-hidden={!labelled}>
        <span className="font-display text-4xl">{name.trim().charAt(0).toUpperCase() || "S"}</span>
      </div>
    );
  }
  return (
    <img
      src={image}
      alt={labelled ? name : ""}
      className={cn("h-full w-full object-cover", className)}
      onError={() => setFailed(true)}
    />
  );
}
