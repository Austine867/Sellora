import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Mark } from "@/components/sellora/site";

export function DashboardFrame({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="min-h-screen bg-background">
        <div className="mx-auto max-w-6xl px-5 py-8">
          <div className="h-8 w-40 animate-pulse rounded-md bg-muted" />
        </div>
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-4">
          <Link to="/dashboard" className="flex items-center gap-2 text-foreground">
            <Mark />
            <span className="font-display text-xl leading-none">Sellora</span>
          </Link>
          <nav className="flex items-center gap-1 text-sm">
            <Link
              to="/dashboard"
              activeOptions={{ exact: true }}
              className="inline-flex h-10 items-center rounded-lg px-3 text-muted-foreground"
              activeProps={{ className: "inline-flex h-10 items-center rounded-lg bg-secondary px-3 text-foreground" }}
            >
              Stores
            </Link>
            <Link
              to="/dashboard/billing"
              className="inline-flex h-10 items-center rounded-lg px-3 text-muted-foreground"
              activeProps={{ className: "inline-flex h-10 items-center rounded-lg bg-secondary px-3 text-foreground" }}
            >
              Billing
            </Link>
          </nav>
          <UserButton />
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-5 py-8">{children}</main>
    </div>
  );
}
