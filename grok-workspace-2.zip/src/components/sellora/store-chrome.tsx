import { useEffect, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import type { PublicStore } from "@/lib/sellora/api";
import { cartCount, useCart } from "@/lib/sellora/cart";

export function StoreChrome({ store, children }: { store: PublicStore; children: ReactNode }) {
  const items = useCart((state) => state.carts[store.slug]);
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  const count = ready ? cartCount(items) : 0;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-4">
          <Link to="/s/$slug" params={{ slug: store.slug }} className="min-w-0">
            <p className="truncate font-display text-2xl text-foreground">{store.name}</p>
            {store.city ? <p className="truncate text-sm text-muted-foreground">{store.city}</p> : null}
          </Link>
          <Link
            to="/s/$slug/checkout"
            params={{ slug: store.slug }}
            className="inline-flex h-11 shrink-0 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
          >
            Bag{count > 0 ? ` · ${count}` : ""}
          </Link>
        </div>
      </header>
      {store.sample ? (
        <p className="border-b border-border bg-secondary px-5 py-3 text-center text-sm text-muted-foreground">
          Sample shop. Orders placed here are saved so you can see the flow. They are not sent to a merchant inbox.
        </p>
      ) : null}
      <div className="mx-auto max-w-6xl px-5 py-8">{children}</div>
      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-6 text-sm text-muted-foreground sm:flex-row sm:justify-between">
          <p>
            {store.name}
            {store.city ? ` · ${store.city}` : ""}
          </p>
          <Link to="/" className="text-foreground">
            Powered by Sellora · WebDev SA
          </Link>
        </div>
      </footer>
    </div>
  );
}

export function MissingShop() {
  return (
    <main className="grid min-h-screen place-items-center bg-background px-6 text-center">
      <div className="max-w-md">
        <h1 className="font-display text-4xl">This shop is not published.</h1>
        <p className="mt-3 text-muted-foreground">The link may be wrong, or the owner has taken the shop offline.</p>
        <Link
          to="/"
          className="mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground"
        >
          Sellora home
        </Link>
      </div>
    </main>
  );
}
