-- Sellora: stores, catalogue, orders, and subscription state.
-- Card capture is not wired. `subscriptions.payment_provider` stays `test`
-- until a PayFast / Yoco webhook confirms a charge.

create table if not exists stores (
  id text primary key,
  user_id text not null,
  name text not null,
  slug text not null unique,
  tagline text not null default '',
  description text not null default '',
  city text not null default '',
  whatsapp text not null default '',
  email text not null default '',
  status text not null default 'live',
  bank_name text not null default '',
  account_holder text not null default '',
  account_number text not null default '',
  branch_code text not null default '',
  pickup_note text not null default '',
  logo_data text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists stores_user_idx on stores (user_id);

create table if not exists products (
  id text primary key,
  store_id text not null references stores (id) on delete cascade,
  user_id text not null,
  name text not null,
  slug text not null,
  description text not null default '',
  price_cents integer not null,
  compare_cents integer,
  stock integer not null default 0,
  sku text not null default '',
  status text not null default 'active',
  image_data text,
  image_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (store_id, slug)
);

create index if not exists products_store_idx on products (store_id);
create index if not exists products_user_idx on products (user_id);

create table if not exists orders (
  id text primary key,
  store_id text not null references stores (id) on delete cascade,
  user_id text not null,
  public_number text not null unique,
  customer_name text not null,
  customer_email text not null,
  customer_phone text not null default '',
  customer_city text not null default '',
  address text not null default '',
  notes text not null default '',
  payment_method text not null,
  status text not null default 'new',
  subtotal_cents integer not null,
  created_at timestamptz not null default now()
);

create index if not exists orders_store_idx on orders (store_id);
create index if not exists orders_user_idx on orders (user_id);
create index if not exists orders_number_idx on orders (public_number);

create table if not exists order_items (
  id text primary key,
  order_id text not null references orders (id) on delete cascade,
  product_id text,
  name text not null,
  qty integer not null,
  unit_cents integer not null
);

create index if not exists order_items_order_idx on order_items (order_id);

create table if not exists subscriptions (
  user_id text primary key,
  plan text not null default 'starter',
  status text not null default 'trial',
  payment_provider text not null default 'test',
  provider_ref text,
  trial_ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into stores (
  id, user_id, name, slug, tagline, description, city, whatsapp, email, status,
  bank_name, account_holder, account_number, branch_code, pickup_note
) values (
  'store_cedar',
  'showcase',
  'Cedar & Salt',
  'cedar-and-salt',
  'Table goods for unhurried rooms.',
  'Stoneware, cloth, and light from a Woodstock studio. Orders are packed twice a week. Pay by EFT or collect from the shop.',
  'Woodstock, Cape Town',
  '',
  'hello@cedarandsalt.example',
  'live',
  'Sample Bank',
  'Cedar & Salt Studio',
  '62000000000',
  '250655',
  'Collect from the Woodstock studio, weekdays 10:00 to 16:00.'
) on conflict (id) do nothing;

insert into products (
  id, store_id, user_id, name, slug, description, price_cents, compare_cents, stock, sku, status, image_path
) values
  (
    'prod_dune', 'store_cedar', 'showcase', 'Dune bowl', 'dune-bowl',
    'Hand-thrown stoneware, sand glaze, about 18 cm across. Food safe. Each piece varies slightly in the rim.',
    42000, null, 12, 'CS-BOWL-18', 'active', '/catalog/dune.svg'
  ),
  (
    'prod_throw', 'store_cedar', 'showcase', 'Harbour throw', 'harbour-throw',
    'Charcoal and cream wool blend, 140 by 200 cm. A weighty layer for the end of a bed or a sofa.',
    89000, 110000, 6, 'CS-THROW-01', 'active', '/catalog/throw.svg'
  ),
  (
    'prod_wick', 'store_cedar', 'showcase', 'Wick holder', 'wick-holder',
    'Matte black holder with a beeswax pillar. Burns for about 40 hours. Unscented.',
    26000, null, 18, 'CS-WICK-40', 'active', '/catalog/wick.svg'
  ),
  (
    'prod_cruet', 'store_cedar', 'showcase', 'Olive cruet', 'olive-cruet',
    'A small pourer for oil or vinegar. Olive ceramic, narrow spout, easy to refill.',
    34000, null, 9, 'CS-CRUET', 'active', '/catalog/cruet.svg'
  )
on conflict (id) do nothing;
