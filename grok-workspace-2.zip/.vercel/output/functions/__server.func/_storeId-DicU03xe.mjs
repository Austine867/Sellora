import { o as __toESM } from "./_runtime.mjs";
import { a as orderStatusLabel, c as slugify, n as formatWhen, o as paymentLabel, r as formatZar, t as centsToRandsInput } from "./_ssr/format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { _ as updateStore, f as getWorkspace, h as setOrderStatus, l as deleteProduct, m as saveProduct, o as Route$6, u as deleteStore } from "./_ssr/router-Boxv0_z9.mjs";
import { t as Button } from "./_ssr/button-DfBJgGpx.mjs";
import { t as ProductVisual } from "./_ssr/product-visual-BACLl9IO.mjs";
import { t as Badge } from "./_ssr/badge-eX066Jot.mjs";
import { t as Input } from "./_ssr/input-r-EVbXg8.mjs";
import { t as Textarea } from "./_ssr/textarea-CUz23fNo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_storeId-DicU03xe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Compress a shop photo in the browser before it is stored. */
function compressImageFile(file) {
	return new Promise((resolve, reject) => {
		if (!file.type.startsWith("image/")) {
			reject(/* @__PURE__ */ new Error("Choose a JPEG, PNG, or WebP image."));
			return;
		}
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, 960 / Math.max(img.width, img.height));
			const width = Math.max(1, Math.round(img.width * scale));
			const height = Math.max(1, Math.round(img.height * scale));
			const canvas = document.createElement("canvas");
			canvas.width = width;
			canvas.height = height;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Could not read that image."));
				return;
			}
			ctx.fillStyle = "#f4f2ec";
			ctx.fillRect(0, 0, width, height);
			ctx.drawImage(img, 0, 0, width, height);
			let quality = .72;
			let data = canvas.toDataURL("image/jpeg", quality);
			while (data.length > 26e4 && quality > .42) {
				quality -= .08;
				data = canvas.toDataURL("image/jpeg", quality);
			}
			URL.revokeObjectURL(url);
			if (data.length > 28e4) {
				reject(/* @__PURE__ */ new Error("That photo is still too large. Try a simpler image."));
				return;
			}
			resolve(data);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Could not read that image."));
		};
		img.src = url;
	});
}
var EMPTY_PRODUCT = {
	name: "",
	description: "",
	priceRands: "",
	compareRands: "",
	stock: "0",
	sku: "",
	status: "active"
};
function StoreWorkspace({ storeId, tab, edit, onTab, onEdit }) {
	const [data, setData] = (0, import_react.useState)(null);
	const [missing, setMissing] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [version, setVersion] = (0, import_react.useState)(0);
	const [query, setQuery] = (0, import_react.useState)("");
	const [orderFilter, setOrderFilter] = (0, import_react.useState)("all");
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setError("");
		getWorkspace({ data: { storeId } }).then((result) => {
			if (cancelled) return;
			if (!result) setMissing(true);
			else setData(result);
		}).catch((caught) => {
			if (!cancelled) setError(caught instanceof Error ? caught.message : "Could not load this store.");
		});
		return () => {
			cancelled = true;
		};
	}, [storeId, version]);
	const link = typeof window !== "undefined" && data ? `${window.location.origin}/s/${data.store.slug}` : "";
	async function copyLink() {
		if (!link) return;
		try {
			await navigator.clipboard.writeText(link);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setError("Could not copy the link. Select it from the address bar of the live shop.");
		}
	}
	if (missing) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl",
		children: "Store not found"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/dashboard",
		className: "mt-4 inline-block text-sm underline",
		children: "Back to stores"
	})] });
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-muted" });
	const products = data.products.filter((product) => product.name.toLowerCase().includes(query.trim().toLowerCase()));
	const orders = data.orders.filter((order) => orderFilter === "all" || order.status === orderFilter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/dashboard",
			className: "text-sm text-muted-foreground",
			children: "All stores"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-col justify-between gap-4 sm:flex-row sm:items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: data.store.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: data.store.status === "live" ? "ok" : "warn",
					children: data.store.status === "live" ? "Live" : "Draft"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: ["/s/", data.store.slug]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => void copyLink(),
						children: copied ? "Copied" : "Copy link"
					}),
					data.store.status === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/s/$slug",
						params: { slug: data.store.slug },
						className: "inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
						children: "Open shop"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "inline-flex h-11 items-center rounded-lg bg-secondary px-4 text-sm font-medium",
						href: `https://wa.me/?text=${encodeURIComponent(`${data.store.name}: ${link || `/s/${data.store.slug}`}`)}`,
						target: "_blank",
						rel: "noreferrer",
						children: "Share"
					})
				]
			})]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-danger",
			children: error
		}) : null,
		notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-ok",
			children: notice
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 flex gap-2 overflow-x-auto",
			children: [
				["products", "Products"],
				["orders", "Orders"],
				["settings", "Settings"]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onTab(id),
				className: tab === id ? "h-10 shrink-0 rounded-lg bg-primary px-4 text-sm text-primary-foreground" : "h-10 shrink-0 rounded-lg bg-secondary px-4 text-sm",
				children: label
			}, id))
		}),
		tab === "products" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-[1fr_320px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search products",
					className: "sm:max-w-xs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => onEdit("new"),
					children: "Add product"
				})]
			}), data.products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted-foreground",
				children: "No products yet. Add one, set the price in rands, and it appears on the shop when it is active."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 divide-y divide-border rounded-xl bg-card ring-1 ring-foreground/10",
				children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-3 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-16 shrink-0 overflow-hidden rounded-md",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
								name: product.name,
								image: product.image,
								className: "size-16"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-medium",
								children: product.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm tabular-nums text-muted-foreground",
								children: [
									formatZar(product.priceCents),
									" · ",
									product.stock,
									" in stock",
									product.status === "draft" ? " · draft" : ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: () => onEdit(product.id),
							children: "Edit"
						})
					]
				}, product.id))
			})] }), edit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductEditor, {
				storeId,
				product: edit === "new" ? null : data.products.find((item) => item.id === edit) ?? null,
				onClose: () => onEdit(void 0),
				onSaved: (message) => {
					setNotice(message);
					setVersion((value) => value + 1);
					onEdit(void 0);
				}
			}, edit) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground lg:pt-12",
				children: [
					data.billing.planName,
					" allows ",
					data.billing.productLimit,
					" products on this account."
				]
			})]
		}) : null,
		tab === "orders" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersPanel, {
			orders,
			filter: orderFilter,
			onFilter: setOrderFilter,
			onChanged: (message) => {
				setNotice(message);
				setVersion((value) => value + 1);
			},
			onError: setError
		}) : null,
		tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {
			data,
			onSaved: (message) => {
				setNotice(message);
				setVersion((value) => value + 1);
			}
		}) : null
	] });
}
function ProductEditor({ storeId, product, onClose, onSaved }) {
	const [form, setForm] = (0, import_react.useState)(() => product ? {
		name: product.name,
		description: product.description,
		priceRands: centsToRandsInput(product.priceCents),
		compareRands: product.compareCents != null ? centsToRandsInput(product.compareCents) : "",
		stock: String(product.stock),
		sku: product.sku,
		status: product.status
	} : EMPTY_PRODUCT);
	const [imageData, setImageData] = (0, import_react.useState)(void 0);
	const [preview, setPreview] = (0, import_react.useState)(product?.image ?? null);
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onFile(file) {
		if (!file) return;
		setError("");
		try {
			const data = await compressImageFile(file);
			setImageData(data);
			setPreview(data);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Could not use that image.");
		}
	}
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError("");
		const result = await saveProduct({ data: {
			storeId,
			id: product?.id,
			name: form.name,
			description: form.description,
			priceRands: form.priceRands,
			compareRands: form.compareRands,
			stock: Number(form.stock),
			sku: form.sku,
			status: form.status,
			imageData
		} });
		setPending(false);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		onSaved(product ? "Product updated." : "Product added.");
	}
	async function onDelete() {
		if (!product) return;
		setPending(true);
		const result = await deleteProduct({ data: { productId: product.id } });
		setPending(false);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		onSaved("Product removed.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "rounded-2xl bg-card p-4 ring-1 ring-foreground/10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: product ? "Edit product" : "New product"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: onClose,
					children: "Close"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 overflow-hidden rounded-lg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
					name: form.name || "Product",
					image: preview,
					labelled: true,
					className: "aspect-square"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm font-medium",
				children: ["Photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mt-1.5 block w-full text-sm",
					type: "file",
					accept: "image/jpeg,image/png,image/webp",
					onChange: (event) => void onFile(event.target.files?.[0])
				})]
			}),
			preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-2 text-sm text-muted-foreground underline",
				onClick: () => {
					setImageData(null);
					setPreview(null);
				},
				children: "Remove photo"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm font-medium",
				children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: form.name,
					onChange: (event) => setForm({
						...form,
						name: event.target.value
					}),
					required: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm font-medium",
				children: ["Description", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-1.5",
					value: form.description,
					onChange: (event) => setForm({
						...form,
						description: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["Price (R)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						inputMode: "decimal",
						value: form.priceRands,
						onChange: (event) => setForm({
							...form,
							priceRands: event.target.value
						}),
						required: true
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["Compare (R)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						inputMode: "decimal",
						value: form.compareRands,
						onChange: (event) => setForm({
							...form,
							compareRands: event.target.value
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["Stock", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						inputMode: "numeric",
						value: form.stock,
						onChange: (event) => setForm({
							...form,
							stock: event.target.value
						}),
						required: true
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["SKU", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						value: form.sku,
						onChange: (event) => setForm({
							...form,
							sku: event.target.value
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm font-medium",
				children: ["Visibility", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "mt-1.5 h-11 w-full rounded-md border border-border bg-card px-3 text-sm",
					value: form.status,
					onChange: (event) => setForm({
						...form,
						status: event.target.value === "draft" ? "draft" : "active"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "active",
						children: "Active on the shop"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "draft",
						children: "Draft, hidden"
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: pending,
					children: pending ? "Saving…" : "Save product"
				}), product ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					disabled: pending,
					onClick: () => void onDelete(),
					children: "Delete"
				}) : null]
			})
		]
	});
}
function OrdersPanel({ orders, filter, onFilter, onChanged, onError }) {
	const [pending, setPending] = (0, import_react.useState)("");
	const filters = [
		"all",
		"new",
		"confirmed",
		"fulfilled",
		"cancelled"
	];
	async function update(orderId, status) {
		setPending(orderId);
		const result = await setOrderStatus({ data: {
			orderId,
			status
		} });
		setPending("");
		if (!result.ok) {
			onError(result.message);
			return;
		}
		onChanged(status === "cancelled" ? "Order cancelled and stock returned." : "Order updated.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex gap-2 overflow-x-auto",
			children: filters.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onFilter(value),
				className: filter === value ? "h-9 shrink-0 rounded-full bg-primary px-3 text-sm text-primary-foreground" : "h-9 shrink-0 rounded-full bg-secondary px-3 text-sm",
				children: value === "all" ? "All" : orderStatusLabel(value)
			}, value))
		}), orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted-foreground",
			children: "No orders in this view. Share the shop link. New orders arrive with the customer’s details and how they chose to pay."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-3",
			children: orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-xl bg-card p-4 ring-1 ring-foreground/10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							children: [
								order.number,
								" · ",
								order.customerName
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								formatWhen(order.createdAt),
								" · ",
								paymentLabel(order.paymentMethod),
								" ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: formatZar(order.subtotalCents)
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: order.status === "cancelled" ? "danger" : order.status === "fulfilled" ? "ok" : "neutral",
							children: orderStatusLabel(order.status)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 text-sm",
						children: order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							item.qty,
							" × ",
							item.name
						] }, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline",
								href: `mailto:${order.customerEmail}`,
								children: order.customerEmail
							}),
							order.customerPhone ? ` · ${order.customerPhone}` : "",
							order.customerCity ? ` · ${order.customerCity}` : ""
						]
					}),
					order.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: order.address
					}) : null,
					order.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: order.notes
					}) : null,
					order.status !== "cancelled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							order.status !== "confirmed" && order.status !== "fulfilled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								disabled: pending === order.id,
								onClick: () => void update(order.id, "confirmed"),
								children: "Confirm"
							}) : null,
							order.status !== "fulfilled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "secondary",
								disabled: pending === order.id,
								onClick: () => void update(order.id, "fulfilled"),
								children: "Mark fulfilled"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "danger",
								disabled: pending === order.id,
								onClick: () => void update(order.id, "cancelled"),
								children: "Cancel"
							})
						]
					}) : null
				]
			}, order.id))
		})]
	});
}
function SettingsPanel({ data, onSaved }) {
	const store = data.store;
	const [form, setForm] = (0, import_react.useState)({
		name: store.name,
		slug: store.slug,
		tagline: store.tagline,
		description: store.description,
		city: store.city,
		whatsapp: store.whatsapp,
		email: store.email,
		status: store.status,
		bankName: store.bank?.bankName ?? "",
		accountHolder: store.bank?.accountHolder ?? "",
		accountNumber: store.bank?.accountNumber ?? "",
		branchCode: store.bank?.branchCode ?? "",
		pickupNote: store.pickupNote
	});
	const [logoData, setLogoData] = (0, import_react.useState)(void 0);
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setForm({
			name: store.name,
			slug: store.slug,
			tagline: store.tagline,
			description: store.description,
			city: store.city,
			whatsapp: store.whatsapp,
			email: store.email,
			status: store.status,
			bankName: store.bank?.bankName ?? "",
			accountHolder: store.bank?.accountHolder ?? "",
			accountNumber: store.bank?.accountNumber ?? "",
			branchCode: store.bank?.branchCode ?? "",
			pickupNote: store.pickupNote
		});
	}, [store]);
	const logo = (0, import_react.useMemo)(() => logoData === null ? null : logoData || store.logo, [logoData, store.logo]);
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError("");
		const result = await updateStore({ data: {
			storeId: store.id,
			...form,
			slug: slugify(form.slug),
			logoData
		} });
		setPending(false);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		setLogoData(void 0);
		onSaved("Store settings saved.");
	}
	async function onDelete() {
		setPending(true);
		const result = await deleteStore({ data: { storeId: store.id } });
		setPending(false);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		window.location.assign("/dashboard");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "mt-6 max-w-xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "size-16 overflow-hidden rounded-lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
						name: form.name || store.name,
						image: logo,
						className: "size-16"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["Logo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1.5 block text-sm",
						type: "file",
						accept: "image/jpeg,image/png,image/webp",
						onChange: (event) => {
							const file = event.target.files?.[0];
							if (!file) return;
							compressImageFile(file).then((dataUrl) => setLogoData(dataUrl)).catch((caught) => setError(caught instanceof Error ? caught.message : "Could not use that logo."));
						}
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: form.name,
					onChange: (event) => setForm({
						...form,
						name: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["Link", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: form.slug,
					onChange: (event) => setForm({
						...form,
						slug: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["Tagline", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: form.tagline,
					onChange: (event) => setForm({
						...form,
						tagline: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["About the shop", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-1.5",
					value: form.description,
					onChange: (event) => setForm({
						...form,
						description: event.target.value
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						value: form.city,
						onChange: (event) => setForm({
							...form,
							city: event.target.value
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm font-medium",
					children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						value: form.email,
						onChange: (event) => setForm({
							...form,
							email: event.target.value
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["WhatsApp (country code, digits)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "mt-1.5",
					value: form.whatsapp,
					onChange: (event) => setForm({
						...form,
						whatsapp: event.target.value
					}),
					placeholder: "27821234567"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["Visibility", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "mt-1.5 h-11 w-full rounded-md border border-border bg-card px-3 text-sm",
					value: form.status,
					onChange: (event) => setForm({
						...form,
						status: event.target.value === "draft" ? "draft" : "live"
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "live",
						children: "Live"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "draft",
						children: "Draft — link returns not published"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "space-y-3 rounded-xl bg-secondary p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "px-1 text-sm font-medium",
						children: "EFT details shown at checkout"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.bankName,
						onChange: (event) => setForm({
							...form,
							bankName: event.target.value
						}),
						placeholder: "Bank"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.accountHolder,
						onChange: (event) => setForm({
							...form,
							accountHolder: event.target.value
						}),
						placeholder: "Account holder"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.accountNumber,
							onChange: (event) => setForm({
								...form,
								accountNumber: event.target.value
							}),
							placeholder: "Account number"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.branchCode,
							onChange: (event) => setForm({
								...form,
								branchCode: event.target.value
							}),
							placeholder: "Branch code"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm font-medium",
				children: ["Collection note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-1.5",
					value: form.pickupNote,
					onChange: (event) => setForm({
						...form,
						pickupNote: event.target.value
					})
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: pending,
				children: pending ? "Saving…" : "Save settings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border pt-4",
				children: confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: "Delete this store, its products, and its orders?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							disabled: pending,
							onClick: () => void onDelete(),
							children: "Delete store"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setConfirmDelete(false),
							children: "Keep it"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => setConfirmDelete(true),
					children: "Delete store"
				})
			})
		]
	});
}
function StoreRoute() {
	const { storeId } = Route$6.useParams();
	const { tab, edit } = Route$6.useSearch();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreWorkspace, {
		storeId,
		tab,
		edit,
		onTab: (next) => {
			navigate({
				to: "/dashboard/stores/$storeId",
				params: { storeId },
				search: { tab: next }
			});
		},
		onEdit: (next) => {
			navigate({
				to: "/dashboard/stores/$storeId",
				params: { storeId },
				search: next ? {
					tab: "products",
					edit: next
				} : { tab: "products" }
			});
		}
	});
}
//#endregion
export { StoreRoute as component };
