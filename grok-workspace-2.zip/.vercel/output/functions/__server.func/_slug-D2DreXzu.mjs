import { r as formatZar } from "./_ssr/format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as Route$5 } from "./_ssr/router-Boxv0_z9.mjs";
import { n as StoreChrome, t as MissingShop } from "./_ssr/store-chrome-DWr1DRWO.mjs";
import { t as ProductVisual } from "./_ssr/product-visual-BACLl9IO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-D2DreXzu.js
var import_jsx_runtime = require_jsx_runtime();
function ShopPage() {
	const data = Route$5.useLoaderData();
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingShop, {});
	const { store, products } = data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StoreChrome, {
		store,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-2xl",
			children: [
				store.logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: store.logo,
					alt: "",
					className: "mb-4 size-16 rounded-lg object-cover"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl sm:text-5xl",
					children: store.name
				}),
				store.tagline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-lg text-muted-foreground",
					children: store.tagline
				}) : null,
				store.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: store.description
				}) : null,
				store.whatsapp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "mt-4 inline-flex h-11 items-center text-sm font-medium underline",
					href: `https://wa.me/${store.whatsapp}`,
					target: "_blank",
					rel: "noreferrer",
					children: "WhatsApp the shop"
				}) : null
			]
		}), products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-10 text-muted-foreground",
			children: "Nothing is on the shelf yet."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-10 grid grid-cols-2 gap-4 lg:grid-cols-3",
			children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/s/$slug/p/$productSlug",
				params: {
					slug: store.slug,
					productSlug: product.slug
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
							name: product.name,
							image: product.image,
							className: "aspect-square"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: product.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "shrink-0 text-sm tabular-nums",
							children: formatZar(product.priceCents)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: product.stock > 0 ? `${product.stock} in stock` : "Sold out"
					})
				]
			}) }, product.id))
		})]
	});
}
//#endregion
export { ShopPage as component };
