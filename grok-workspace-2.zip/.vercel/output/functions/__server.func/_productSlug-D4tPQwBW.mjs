import { o as __toESM } from "./_runtime.mjs";
import { r as formatZar } from "./_ssr/format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./_ssr/router-Boxv0_z9.mjs";
import { i as useCart, n as StoreChrome, t as MissingShop } from "./_ssr/store-chrome-DWr1DRWO.mjs";
import { t as Button } from "./_ssr/button-DfBJgGpx.mjs";
import { t as ProductVisual } from "./_ssr/product-visual-BACLl9IO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_productSlug-D4tPQwBW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const data = Route.useLoaderData();
	const add = useCart((state) => state.add);
	const [qty, setQty] = (0, import_react.useState)(1);
	const [added, setAdded] = (0, import_react.useState)(false);
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingShop, {});
	const { store, product } = data;
	const max = Math.max(0, Math.min(99, product.stock));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StoreChrome, {
		store,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/s/$slug",
			params: { slug: store.slug },
			className: "text-sm text-muted-foreground",
			children: ["Back to ", store.name]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-8 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-2xl bg-card ring-1 ring-foreground/10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
					name: product.name,
					image: product.image,
					labelled: true,
					className: "aspect-square"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: product.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 flex items-baseline gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-3xl tabular-nums",
						children: formatZar(product.priceCents)
					}), product.compareCents && product.compareCents > product.priceCents ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground line-through tabular-nums",
						children: formatZar(product.compareCents)
					}) : null]
				}),
				product.sku ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: ["SKU ", product.sku]
				}) : null,
				product.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: product.description
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm",
					children: max > 0 ? `${product.stock} in stock` : "Sold out"
				}),
				max > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["Qty", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "ml-2 h-11 w-16 rounded-md border border-border bg-card px-2 text-center tabular-nums",
								inputMode: "numeric",
								value: qty,
								onChange: (event) => {
									const next = Math.floor(Number(event.target.value));
									if (!Number.isFinite(next)) return;
									setQty(Math.min(max, Math.max(1, next)));
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							onClick: () => {
								add(store.slug, {
									productId: product.id,
									name: product.name,
									priceCents: product.priceCents,
									image: product.image
								}, qty);
								setAdded(true);
							},
							children: "Add to bag"
						}),
						added ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/s/$slug/checkout",
							params: { slug: store.slug },
							className: "text-sm underline",
							children: "Go to checkout"
						}) : null
					]
				}) : null
			] })]
		})]
	});
}
//#endregion
export { ProductPage as component };
