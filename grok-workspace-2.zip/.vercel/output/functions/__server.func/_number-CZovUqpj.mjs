import { a as orderStatusLabel, n as formatWhen, o as paymentLabel, r as formatZar } from "./_ssr/format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./_ssr/router-Boxv0_z9.mjs";
import { t as MissingShop } from "./_ssr/store-chrome-DWr1DRWO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_number-CZovUqpj.js
var import_jsx_runtime = require_jsx_runtime();
function OrderPage() {
	const order = Route$1.useLoaderData();
	if (!order) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingShop, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-lg px-5 py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: order.storeName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-2 font-display text-4xl",
					children: ["Order ", order.number]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-muted-foreground",
					children: [
						orderStatusLabel(order.status),
						" · ",
						paymentLabel(order.paymentMethod),
						" · ",
						formatWhen(order.createdAt)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm",
					children: ["Placed by ", order.customerName]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-6 divide-y divide-border rounded-xl bg-card ring-1 ring-foreground/10",
					children: [order.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3 px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							item.qty,
							" × ",
							item.name
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: formatZar(item.qty * item.unitCents)
						})]
					}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between px-4 py-3 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: formatZar(order.subtotalCents)
						})]
					})]
				}),
				order.bank ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-xl bg-secondary p-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "EFT to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: order.bank.bankName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: order.bank.accountHolder }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums",
							children: order.bank.accountNumber
						}),
						order.bank.branchCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Branch ", order.bank.branchCode] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-muted-foreground",
							children: ["Reference: ", order.number]
						})
					]
				}) : null,
				order.pickupNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 rounded-xl bg-secondary p-4 text-sm",
					children: order.pickupNote
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/s/$slug",
					params: { slug: order.slug },
					className: "mt-8 inline-block text-sm underline",
					children: "Back to the shop"
				})
			]
		})
	});
}
//#endregion
export { OrderPage as component };
