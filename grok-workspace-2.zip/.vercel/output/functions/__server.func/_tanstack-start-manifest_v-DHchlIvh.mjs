//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHchlIvh.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/dashboard",
			"/login",
			"/api/auth/$",
			"/s/$slug/checkout",
			"/s/$slug/",
			"/api/media/product/$productId",
			"/api/media/store/$storeId",
			"/s/$slug/order/$number",
			"/s/$slug/p/$productSlug"
		],
		preloads: [
			"/assets/index-CB9wRAyv.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/api-BrAfkRO6.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/link-CjZ2n7Rf.js",
			"/assets/matchContext-B4A6rP5h.js",
			"/assets/lazyRouteComponent-Dp_a5MWd.js",
			"/assets/useNavigate-BEXsx_-t.js",
			"/assets/jsx-runtime-BtH0gOTJ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CB9wRAyv.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D2QM6mM_.js",
			"/assets/site-jgG17rYs.js",
			"/assets/format-ywjP31r1.js",
			"/assets/plans-Dl4LaXtR.js",
			"/assets/product-visual-BvNc_8S8.js"
		]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: [
			"/dashboard/billing",
			"/dashboard/new",
			"/dashboard/",
			"/dashboard/stores/$storeId"
		],
		preloads: [
			"/assets/dashboard-CAObYGHm.js",
			"/assets/site-jgG17rYs.js",
			"/assets/client-cLw6edTc.js",
			"/assets/use-current-user-DQB55Vmc.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DOz1WR-r.js",
			"/assets/site-jgG17rYs.js",
			"/assets/client-cLw6edTc.js",
			"/assets/button-Cw8xs5_M.js",
			"/assets/input-Qfmx3j7y.js"
		]
	},
	"/dashboard/billing": {
		filePath: "/workspace/src/routes/dashboard/billing.tsx",
		children: void 0,
		preloads: [
			"/assets/billing-82RfXEt7.js",
			"/assets/button-Cw8xs5_M.js",
			"/assets/format-ywjP31r1.js",
			"/assets/plans-Dl4LaXtR.js"
		]
	},
	"/dashboard/new": {
		filePath: "/workspace/src/routes/dashboard/new.tsx",
		children: void 0,
		preloads: [
			"/assets/new-D-aZ2OG3.js",
			"/assets/button-Cw8xs5_M.js",
			"/assets/format-ywjP31r1.js",
			"/assets/input-Qfmx3j7y.js"
		]
	},
	"/dashboard/": {
		filePath: "/workspace/src/routes/dashboard/index.tsx",
		children: void 0,
		preloads: ["/assets/dashboard-s5I4TyaD.js", "/assets/badge-BcVt_DMy.js"]
	},
	"/dashboard/stores/$storeId": {
		filePath: "/workspace/src/routes/dashboard/stores/$storeId.tsx",
		children: void 0,
		preloads: [
			"/assets/_storeId-B6RxbioA.js",
			"/assets/button-Cw8xs5_M.js",
			"/assets/format-ywjP31r1.js",
			"/assets/badge-BcVt_DMy.js",
			"/assets/input-Qfmx3j7y.js",
			"/assets/textarea-cmTKAFXX.js",
			"/assets/product-visual-BvNc_8S8.js"
		]
	},
	"/s/$slug/checkout": {
		filePath: "/workspace/src/routes/s/$slug/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-Zwd7Klk9.js",
			"/assets/button-Cw8xs5_M.js",
			"/assets/format-ywjP31r1.js",
			"/assets/input-Qfmx3j7y.js",
			"/assets/textarea-cmTKAFXX.js",
			"/assets/product-visual-BvNc_8S8.js",
			"/assets/store-chrome-Bq4qItHi.js"
		]
	},
	"/s/$slug/": {
		filePath: "/workspace/src/routes/s/$slug/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-B2Ys9Xsf.js",
			"/assets/format-ywjP31r1.js",
			"/assets/product-visual-BvNc_8S8.js",
			"/assets/store-chrome-Bq4qItHi.js"
		]
	},
	"/s/$slug/order/$number": {
		filePath: "/workspace/src/routes/s/$slug/order/$number.tsx",
		children: void 0,
		preloads: [
			"/assets/_number-DVZhWvoX.js",
			"/assets/format-ywjP31r1.js",
			"/assets/store-chrome-Bq4qItHi.js"
		]
	},
	"/s/$slug/p/$productSlug": {
		filePath: "/workspace/src/routes/s/$slug/p/$productSlug.tsx",
		children: void 0,
		preloads: [
			"/assets/_productSlug-Bw9Savz8.js",
			"/assets/button-Cw8xs5_M.js",
			"/assets/format-ywjP31r1.js",
			"/assets/product-visual-BvNc_8S8.js",
			"/assets/store-chrome-Bq4qItHi.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
