import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-chrome-DWr1DRWO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var useCart = create()(persist((set, get) => ({
	carts: {},
	add: (slug, item, qty = 1) => {
		const current = get().carts[slug] ?? [];
		const next = current.find((entry) => entry.productId === item.productId) ? current.map((entry) => entry.productId === item.productId ? {
			...entry,
			qty: Math.min(99, entry.qty + qty),
			priceCents: item.priceCents
		} : entry) : [...current, {
			...item,
			qty
		}];
		set({ carts: {
			...get().carts,
			[slug]: next
		} });
	},
	setQty: (slug, productId, qty) => {
		const current = get().carts[slug] ?? [];
		const next = qty <= 0 ? current.filter((entry) => entry.productId !== productId) : current.map((entry) => entry.productId === productId ? {
			...entry,
			qty
		} : entry);
		set({ carts: {
			...get().carts,
			[slug]: next
		} });
	},
	clear: (slug) => {
		const carts = { ...get().carts };
		delete carts[slug];
		set({ carts });
	}
}), { name: "sellora-cart" }));
function cartCount(items) {
	return (items ?? []).reduce((sum, item) => sum + item.qty, 0);
}
function cartTotal(items) {
	return (items ?? []).reduce((sum, item) => sum + item.qty * item.priceCents, 0);
}
function StoreChrome({ store, children }) {
	const items = useCart((state) => state.carts[store.slug]);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	const count = ready ? cartCount(items) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/s/$slug",
						params: { slug: store.slug },
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display text-2xl text-foreground",
							children: store.name
						}), store.city ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-muted-foreground",
							children: store.city
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/s/$slug/checkout",
						params: { slug: store.slug },
						className: "inline-flex h-11 shrink-0 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
						children: ["Bag", count > 0 ? ` · ${count}` : ""]
					})]
				})
			}),
			store.sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-b border-border bg-secondary px-5 py-3 text-center text-sm text-muted-foreground",
				children: "Sample shop. Orders placed here are saved so you can see the flow. They are not sent to a merchant inbox."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-6xl px-5 py-8",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-2 px-5 py-6 text-sm text-muted-foreground sm:flex-row sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [store.name, store.city ? ` · ${store.city}` : ""] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "text-foreground",
						children: "Powered by Sellora · WebDev SA"
					})]
				})
			})
		]
	});
}
function MissingShop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-background px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "This shop is not published."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: "The link may be wrong, or the owner has taken the shop offline."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
					children: "Sellora home"
				})
			]
		})
	});
}
//#endregion
export { useCart as i, StoreChrome as n, cartTotal as r, MissingShop as t };
