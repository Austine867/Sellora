//#region node_modules/.nitro/vite/services/ssr/assets/format-B_5Dlkxi.js
var RESERVED = /* @__PURE__ */ new Set([
	"dashboard",
	"login",
	"api",
	"s",
	"billing",
	"admin",
	"app",
	"sellora",
	"pricing",
	"auth",
	"new",
	"www",
	"checkout",
	"order"
]);
function slugify(value) {
	return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}
function isReservedSlug(slug) {
	return RESERVED.has(slug);
}
function formatZar(cents) {
	return new Intl.NumberFormat("en-ZA", {
		style: "currency",
		currency: "ZAR",
		minimumFractionDigits: cents % 100 === 0 ? 0 : 2,
		maximumFractionDigits: 2
	}).format(cents / 100);
}
function randsToCents(raw) {
	const t = raw.trim().replace(/\s/g, "").replace(/^R/i, "").replace(/,/g, "");
	if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
	const [whole, frac = ""] = t.split(".");
	const cents = Number(whole) * 100 + Number((frac + "00").slice(0, 2));
	if (!Number.isInteger(cents) || cents < 0 || cents > 1e7) return null;
	return cents;
}
function centsToRandsInput(cents) {
	const whole = Math.floor(cents / 100);
	const frac = cents % 100;
	return frac === 0 ? String(whole) : `${whole}.${String(frac).padStart(2, "0")}`;
}
function formatWhen(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return value;
	return new Intl.DateTimeFormat("en-ZA", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	}).format(date);
}
function paymentLabel(method) {
	if (method === "eft") return "EFT";
	if (method === "collection") return "Pay on collection";
	return method;
}
function orderStatusLabel(status) {
	if (status === "new") return "New";
	if (status === "confirmed") return "Confirmed";
	if (status === "fulfilled") return "Fulfilled";
	if (status === "cancelled") return "Cancelled";
	return status;
}
//#endregion
export { orderStatusLabel as a, slugify as c, isReservedSlug as i, formatWhen as n, paymentLabel as o, formatZar as r, randsToCents as s, centsToRandsInput as t };
