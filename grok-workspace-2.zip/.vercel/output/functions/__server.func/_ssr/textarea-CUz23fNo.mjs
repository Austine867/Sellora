import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/textarea-CUz23fNo.js
var import_jsx_runtime = require_jsx_runtime();
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-28 w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none", "placeholder:text-muted-foreground focus:border-foreground", className),
		...props
	});
}
//#endregion
export { Textarea as t };
