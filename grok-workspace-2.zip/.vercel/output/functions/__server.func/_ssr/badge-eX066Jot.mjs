import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-eX066Jot.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-6 items-center rounded-full px-2 text-xs font-medium", tone === "neutral" && "bg-secondary text-foreground", tone === "ok" && "bg-secondary text-ok", tone === "warn" && "bg-secondary text-warn", tone === "danger" && "bg-secondary text-danger", className),
		...props
	});
}
//#endregion
export { Badge as t };
