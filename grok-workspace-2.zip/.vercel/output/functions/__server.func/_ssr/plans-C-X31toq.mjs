//#region node_modules/.nitro/vite/services/ssr/assets/plans-C-X31toq.js
var PLANS = [
	{
		id: "starter",
		name: "Starter",
		priceZar: 99,
		stores: 1,
		products: 40,
		blurb: "One shop, ready to share this week.",
		features: [
			"1 store",
			"40 products",
			"Stock and orders",
			"Your own shop link"
		]
	},
	{
		id: "growth",
		name: "Growth",
		priceZar: 249,
		stores: 3,
		products: 250,
		blurb: "For a business with more than one range.",
		features: [
			"3 stores",
			"250 products",
			"EFT details on checkout",
			"Order statuses"
		]
	},
	{
		id: "scale",
		name: "Scale",
		priceZar: 599,
		stores: 50,
		products: 5e3,
		blurb: "When the catalogue no longer fits a spreadsheet.",
		features: [
			"50 stores",
			"5,000 products",
			"Same workspace, higher limits",
			"Billing hook ready"
		]
	}
];
function planById(id) {
	return PLANS.find((plan) => plan.id === id) ?? PLANS[0];
}
//#endregion
export { planById as n, PLANS as t };
