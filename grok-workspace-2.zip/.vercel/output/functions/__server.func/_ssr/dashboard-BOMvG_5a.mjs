import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as getHome } from "./router-Boxv0_z9.mjs";
import { t as Badge } from "./badge-eX066Jot.mjs";
import { t as useCurrentUser } from "./use-current-user-B7Cbrtsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-BOMvG_5a.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DashboardHome() {
	const user = useCurrentUser();
	const [data, setData] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getHome().then((result) => {
			if (!cancelled) setData(result);
		}).catch((caught) => {
			if (!cancelled) setError(caught instanceof Error ? caught.message : "Could not load your stores.");
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const first = user?.displayName?.split(" ")[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-between gap-4 sm:flex-row sm:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: first ? `${first}, your stores` : "Your stores"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: data ? `${data.billing.planName} · R${data.billing.priceZar}/month · ${data.billing.paymentProvider === "test" ? "test mode, no charge" : data.billing.status}` : "Loading the workspace…"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dashboard/new",
				className: "inline-flex h-11 items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
				children: "New store"
			})]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-danger",
			children: error
		}) : null,
		data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
			className: "mt-8 grid grid-cols-3 gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Products",
					value: data.totals.products
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Orders",
					value: data.totals.openOrders
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Low stock",
					value: data.totals.attention
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-8 h-20 animate-pulse rounded-xl bg-muted" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-4",
			children: [data && data.stores.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-card p-8 ring-1 ring-foreground/10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "No store yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-md text-muted-foreground",
						children: "Name it, publish the link, then add the first product. Customers can order as soon as the shop is live."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dashboard/new",
						className: "mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
						children: "Create a store"
					})
				]
			}) : null, data?.stores.map((store) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/dashboard/stores/$storeId",
				params: { storeId: store.id },
				search: { tab: "products" },
				className: "rounded-2xl bg-card p-5 ring-1 ring-foreground/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: store.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"/s/",
							store.slug,
							store.city ? ` · ${store.city}` : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: store.status === "live" ? "ok" : "warn",
						children: store.status === "live" ? "Live" : "Draft"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm tabular-nums text-muted-foreground",
					children: [
						store.productCount,
						" products · ",
						store.orderCount,
						" orders",
						store.attentionCount > 0 ? ` · ${store.attentionCount} need stock` : ""
					]
				})]
			}, store.id))]
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 ring-1 ring-foreground/10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-3xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { DashboardHome as component };
