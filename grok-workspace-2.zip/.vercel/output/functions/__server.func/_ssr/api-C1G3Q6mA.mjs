import { c as slugify, i as isReservedSlug, s as randsToCents } from "./format-B_5Dlkxi.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as getSql, t as authMiddleware } from "./middleware-B1lhXKUH.mjs";
import { n as planById } from "./plans-C-X31toq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-C1G3Q6mA.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function fail(message) {
	return {
		ok: false,
		message
	};
}
function text(value, max) {
	if (typeof value !== "string") return "";
	return value.trim().slice(0, max);
}
function stamp(value) {
	if (value instanceof Date) return value.toISOString();
	if (typeof value === "string") return value;
	return value == null ? "" : String(value);
}
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function validImage(data) {
	if (data.length > 28e4) return false;
	return data.startsWith("data:image/jpeg;base64,") || data.startsWith("data:image/png;base64,") || data.startsWith("data:image/webp;base64,");
}
function flag(value) {
	return value === true || value === "t" || value === "true" || value === 1;
}
function productImage(row) {
	if (row.image_path) return row.image_path;
	if (flag(row.has_image)) return `/api/media/product/${row.id}`;
	return null;
}
function bankFrom(row) {
	if (!row.bank_name && !row.account_number) return null;
	return {
		bankName: row.bank_name,
		accountHolder: row.account_holder,
		accountNumber: row.account_number,
		branchCode: row.branch_code
	};
}
function toPublicStore(row) {
	return {
		name: row.name,
		slug: row.slug,
		tagline: row.tagline,
		description: row.description,
		city: row.city,
		whatsapp: row.whatsapp,
		email: row.email,
		logo: flag(row.has_logo) ? `/api/media/store/${row.id}` : null,
		sample: row.user_id === "showcase",
		pickupNote: row.pickup_note,
		bank: bankFrom(row)
	};
}
function toProduct(row) {
	const status = row.status === "draft" ? "draft" : "active";
	return {
		id: row.id,
		name: row.name,
		slug: row.slug,
		description: row.description,
		priceCents: num(row.price_cents),
		compareCents: row.compare_cents == null ? null : num(row.compare_cents),
		stock: num(row.stock),
		sku: row.sku,
		status,
		image: productImage(row)
	};
}
var STORE_FIELDS = `
  id, user_id, name, slug, tagline, description, city, whatsapp, email, status,
  bank_name, account_holder, account_number, branch_code, pickup_note,
  (logo_data is not null) as has_logo
`;
var PRODUCT_FIELDS = `
  id, name, slug, description, price_cents, compare_cents, stock, sku, status,
  image_path, (image_data is not null) as has_image
`;
async function ensureSub(sql, userId) {
	await sql`
    insert into subscriptions (user_id, plan, status, payment_provider, trial_ends_at)
    values (${userId}, 'starter', 'trial', 'test', now() + interval '14 days')
    on conflict (user_id) do nothing
  `;
	const row = (await sql`
    select plan, status, payment_provider, trial_ends_at
    from subscriptions where user_id = ${userId}
  `)[0];
	const plan = planById(row?.plan ?? "starter");
	return {
		plan: plan.id,
		planName: plan.name,
		priceZar: plan.priceZar,
		status: row?.status ?? "trial",
		paymentProvider: row?.payment_provider ?? "test",
		trialEndsAt: row?.trial_ends_at ? stamp(row.trial_ends_at) : null,
		storeLimit: plan.stores,
		productLimit: plan.products
	};
}
async function selectStore(sql, where, params) {
	return (await sql.query(`select ${STORE_FIELDS} from stores where ${where}`, params))[0] ?? null;
}
async function selectProducts(sql, where, params) {
	return sql.query(`select ${PRODUCT_FIELDS} from products where ${where} order by created_at desc`, params);
}
function orderNumber() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(8));
	let value = "SL-";
	for (const byte of bytes) value += alphabet[byte % 32];
	return value;
}
function toOrder(row, items) {
	return {
		id: row.id,
		number: row.public_number,
		customerName: row.customer_name,
		customerEmail: row.customer_email,
		customerPhone: row.customer_phone,
		customerCity: row.customer_city,
		address: row.address,
		notes: row.notes,
		paymentMethod: row.payment_method,
		status: row.status,
		subtotalCents: num(row.subtotal_cents),
		createdAt: stamp(row.created_at),
		items: items.map((item) => ({
			id: item.id,
			productId: item.product_id,
			name: item.name,
			qty: num(item.qty),
			unitCents: num(item.unit_cents)
		}))
	};
}
async function ordersForStore(sql, storeId) {
	const rows = await sql`
    select id, public_number, customer_name, customer_email, customer_phone, customer_city,
           address, notes, payment_method, status, subtotal_cents, created_at
    from orders where store_id = ${storeId}
    order by created_at desc
    limit 100
  `;
	if (rows.length === 0) return [];
	const params = [];
	const slots = rows.map((row, index) => {
		params.push(row.id);
		return `$${index + 1}`;
	});
	const items = await sql.query(`select id, order_id, product_id, name, qty, unit_cents from order_items where order_id in (${slots.join(",")})`, params);
	return rows.map((row) => toOrder(row, items.filter((item) => item.order_id === row.id)));
}
var getPublicStorefront_createServerFn_handler = createServerRpc({
	id: "54507828ad7e9b98dcfdcc2a8df75fce11e87751c2fc64218b3248d115ff584d",
	name: "getPublicStorefront",
	filename: "src/lib/sellora/api.ts"
}, (opts) => getPublicStorefront.__executeServer(opts));
var getPublicStorefront = createServerFn({ method: "GET" }).validator((input) => ({ slug: text(input?.slug, 40) })).handler(getPublicStorefront_createServerFn_handler, async ({ data }) => {
	if (!data.slug) return null;
	const sql = await getSql();
	const store = await selectStore(sql, "slug = $1 and status = 'live'", [data.slug]);
	if (!store) return null;
	const products = await selectProducts(sql, "store_id = $1 and status = 'active'", [store.id]);
	return {
		store: toPublicStore(store),
		products: products.map(toProduct)
	};
});
var getPublicProduct_createServerFn_handler = createServerRpc({
	id: "9d6c9d8e5a70bf6302fe7f828084fd7f75be822da89e3c4ceed4f34bd5dd24c7",
	name: "getPublicProduct",
	filename: "src/lib/sellora/api.ts"
}, (opts) => getPublicProduct.__executeServer(opts));
var getPublicProduct = createServerFn({ method: "GET" }).validator((input) => ({
	slug: text(input?.slug, 40),
	productSlug: text(input?.productSlug, 60)
})).handler(getPublicProduct_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const store = await selectStore(sql, "slug = $1 and status = 'live'", [data.slug]);
	if (!store) return null;
	const product = (await selectProducts(sql, "store_id = $1 and slug = $2 and status = 'active'", [store.id, data.productSlug]))[0];
	if (!product) return null;
	return {
		store: toPublicStore(store),
		product: toProduct(product)
	};
});
var getPublicOrder_createServerFn_handler = createServerRpc({
	id: "df102c9c122d304de826b910b467a1851f41538587d9b19f4397b2178b25c633",
	name: "getPublicOrder",
	filename: "src/lib/sellora/api.ts"
}, (opts) => getPublicOrder.__executeServer(opts));
var getPublicOrder = createServerFn({ method: "GET" }).validator((input) => ({
	slug: text(input?.slug, 40),
	number: text(input?.number, 20).toUpperCase()
})).handler(getPublicOrder_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const store = await selectStore(sql, "slug = $1", [data.slug]);
	if (!store) return null;
	const row = (await sql`
      select id, public_number, customer_name, customer_email, customer_phone, customer_city,
             address, notes, payment_method, status, subtotal_cents, created_at
      from orders where store_id = ${store.id} and public_number = ${data.number}
    `)[0];
	if (!row) return null;
	const order = toOrder(row, await sql`
      select id, order_id, product_id, name, qty, unit_cents
      from order_items where order_id = ${row.id}
    `);
	return {
		number: order.number,
		status: order.status,
		paymentMethod: order.paymentMethod,
		subtotalCents: order.subtotalCents,
		createdAt: order.createdAt,
		customerName: order.customerName,
		items: order.items,
		bank: order.paymentMethod === "eft" ? bankFrom(store) : null,
		pickupNote: order.paymentMethod === "collection" ? store.pickup_note : "",
		storeName: store.name,
		slug: store.slug
	};
});
var placeOrder_createServerFn_handler = createServerRpc({
	id: "18bb235a40c1f79cd05282c41f2a796e65cbf4316a7ab74ada11517e252e3dc5",
	name: "placeOrder",
	filename: "src/lib/sellora/api.ts"
}, (opts) => placeOrder.__executeServer(opts));
var placeOrder = createServerFn({ method: "POST" }).validator((input) => input).handler(placeOrder_createServerFn_handler, async ({ data }) => {
	const slug = text(data?.slug, 40);
	const name = text(data?.customer?.name, 80);
	const email = text(data?.customer?.email, 120);
	const phone = text(data?.customer?.phone, 30);
	const city = text(data?.customer?.city, 80);
	const address = text(data?.customer?.address, 240);
	const notes = text(data?.customer?.notes, 400);
	const paymentMethod = data?.paymentMethod === "collection" ? "collection" : data?.paymentMethod === "eft" ? "eft" : "";
	if (!slug) return fail("Choose a shop.");
	if (name.length < 2) return fail("Add the customer name.");
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Add a valid email address.");
	if (!paymentMethod) return fail("Choose how this order will be paid.");
	const rawItems = Array.isArray(data?.items) ? data.items : [];
	const merged = /* @__PURE__ */ new Map();
	for (const item of rawItems) {
		const id = text(item?.productId, 80);
		const qty = Math.floor(num(item?.qty));
		if (!id || qty < 1 || qty > 99) continue;
		merged.set(id, Math.min(99, (merged.get(id) ?? 0) + qty));
	}
	if (merged.size === 0) return fail("Your bag is empty.");
	if (merged.size > 30) return fail("Too many different products in one order.");
	const sql = await getSql();
	const store = await selectStore(sql, "slug = $1 and status = 'live'", [slug]);
	if (!store) return fail("This shop is not taking orders.");
	const ids = [...merged.keys()];
	const params = [store.id, ...ids];
	const slots = ids.map((_, index) => `$${index + 2}`);
	const products = await sql.query(`select id, name, price_cents, stock, status from products where store_id = $1 and id in (${slots.join(",")})`, params);
	const byId = new Map(products.map((product) => [product.id, product]));
	const lines = [];
	for (const [id, qty] of merged) {
		const product = byId.get(id);
		if (!product || product.status !== "active") return fail("A product in your bag is no longer available.");
		if (num(product.stock) < qty) return fail(`${product.name} only has ${num(product.stock)} in stock.`);
		lines.push({
			id,
			name: product.name,
			qty,
			unit: num(product.price_cents)
		});
	}
	const decremented = [];
	let createdOrderId = null;
	try {
		for (const line of lines) {
			if ((await sql`
          update products
          set stock = stock - ${line.qty}, updated_at = now()
          where id = ${line.id} and store_id = ${store.id} and status = 'active' and stock >= ${line.qty}
          returning id
        `).length === 0) throw new Error(`${line.name} just sold out. Adjust the quantity and try again.`);
			decremented.push({
				id: line.id,
				qty: line.qty
			});
		}
		const subtotal = lines.reduce((sum, line) => sum + line.qty * line.unit, 0);
		const id = crypto.randomUUID();
		let number = orderNumber();
		for (let attempt = 0; attempt < 3; attempt += 1) {
			if ((await sql`select id from orders where public_number = ${number}`).length === 0) break;
			number = orderNumber();
		}
		await sql`
        insert into orders (
          id, store_id, user_id, public_number, customer_name, customer_email, customer_phone,
          customer_city, address, notes, payment_method, status, subtotal_cents
        ) values (
          ${id}, ${store.id}, ${store.user_id}, ${number}, ${name}, ${email}, ${phone},
          ${city}, ${address}, ${notes}, ${paymentMethod}, 'new', ${subtotal}
        )
      `;
		createdOrderId = id;
		for (const line of lines) await sql`
          insert into order_items (id, order_id, product_id, name, qty, unit_cents)
          values (${crypto.randomUUID()}, ${id}, ${line.id}, ${line.name}, ${line.qty}, ${line.unit})
        `;
		return {
			ok: true,
			data: { number }
		};
	} catch (error) {
		if (createdOrderId) await sql`delete from orders where id = ${createdOrderId}`;
		for (const entry of decremented) await sql`update products set stock = stock + ${entry.qty}, updated_at = now() where id = ${entry.id}`;
		return fail(error instanceof Error ? error.message : "Could not place the order.");
	}
});
var getHome_createServerFn_handler = createServerRpc({
	id: "0a0ffa222e8ab9ebd82e3c8b6d1cc7979efb589f5a03d52b6391f2710af51f9a",
	name: "getHome",
	filename: "src/lib/sellora/api.ts"
}, (opts) => getHome.__executeServer(opts));
var getHome = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getHome_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const billing = await ensureSub(sql, context.userId);
	const stores = (await sql`
      select s.id, s.name, s.slug, s.city, s.status,
        (select count(*) from products p where p.store_id = s.id) as product_count,
        (select count(*) from orders o where o.store_id = s.id and o.status <> 'cancelled') as order_count,
        (select count(*) from products p where p.store_id = s.id and p.status = 'active' and p.stock <= 3) as attention_count
      from stores s
      where s.user_id = ${context.userId}
      order by s.created_at desc
    `).map((row) => ({
		id: row.id,
		name: row.name,
		slug: row.slug,
		city: row.city,
		status: row.status,
		productCount: num(row.product_count),
		orderCount: num(row.order_count),
		attentionCount: num(row.attention_count)
	}));
	return {
		billing,
		stores,
		totals: {
			products: stores.reduce((sum, store) => sum + store.productCount, 0),
			openOrders: stores.reduce((sum, store) => sum + store.orderCount, 0),
			attention: stores.reduce((sum, store) => sum + store.attentionCount, 0)
		}
	};
});
var createStore_createServerFn_handler = createServerRpc({
	id: "9863935f911ef2825e08cf2043798dc05083b2a86afb07916b980bf26582e948",
	name: "createStore",
	filename: "src/lib/sellora/api.ts"
}, (opts) => createStore.__executeServer(opts));
var createStore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createStore_createServerFn_handler, async ({ context, data }) => {
	const name = text(data?.name, 80);
	const slug = slugify(text(data?.slug, 40) || name);
	const city = text(data?.city, 80);
	const tagline = text(data?.tagline, 140);
	if (name.length < 2) return fail("Give the shop a name.");
	if (slug.length < 3 || isReservedSlug(slug)) return fail("Choose a longer, simpler link name.");
	const sql = await getSql();
	const billing = await ensureSub(sql, context.userId);
	if (num((await sql`select count(*) as n from stores where user_id = ${context.userId}`)[0]?.n) >= billing.storeLimit) return fail(`${billing.planName} includes ${billing.storeLimit} store${billing.storeLimit === 1 ? "" : "s"}. Change plan on Billing to add another.`);
	if ((await sql`select id from stores where slug = ${slug}`).length > 0) return fail("That shop link is already taken.");
	const id = crypto.randomUUID();
	const status = data?.publish === false ? "draft" : "live";
	await sql`
      insert into stores (id, user_id, name, slug, tagline, city, status)
      values (${id}, ${context.userId}, ${name}, ${slug}, ${tagline}, ${city}, ${status})
    `;
	return {
		ok: true,
		data: { id }
	};
});
var getWorkspace_createServerFn_handler = createServerRpc({
	id: "598785791b506d769a2cb8544a11d492a4c3bd2356c9712ae1d95b3f2e65aa48",
	name: "getWorkspace",
	filename: "src/lib/sellora/api.ts"
}, (opts) => getWorkspace.__executeServer(opts));
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => ({ storeId: text(input?.storeId, 80) })).handler(getWorkspace_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const billing = await ensureSub(sql, context.userId);
	const store = await selectStore(sql, "id = $1 and user_id = $2", [data.storeId, context.userId]);
	if (!store) return null;
	const products = await selectProducts(sql, "store_id = $1 and user_id = $2", [store.id, context.userId]);
	const orders = await ordersForStore(sql, store.id);
	return {
		billing,
		store: {
			...toPublicStore(store),
			id: store.id,
			status: store.status === "draft" ? "draft" : "live"
		},
		products: products.map(toProduct),
		orders
	};
});
var updateStore_createServerFn_handler = createServerRpc({
	id: "27488c6acdab84f6c449d7fc482b50aeff2a86fce7dc39b5efe332a490765785",
	name: "updateStore",
	filename: "src/lib/sellora/api.ts"
}, (opts) => updateStore.__executeServer(opts));
var updateStore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(updateStore_createServerFn_handler, async ({ context, data }) => {
	const storeId = text(data?.storeId, 80);
	const name = text(data?.name, 80);
	const slug = slugify(text(data?.slug, 40));
	const email = text(data?.email, 120);
	const whatsapp = text(data?.whatsapp, 20).replace(/\D/g, "");
	const status = data?.status === "draft" ? "draft" : "live";
	if (name.length < 2) return fail("The shop needs a name.");
	if (slug.length < 3 || isReservedSlug(slug)) return fail("That link name will not work.");
	if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("That email does not look right.");
	if (whatsapp && (whatsapp.length < 8 || whatsapp.length > 15)) return fail("Enter a WhatsApp number with country code, digits only.");
	if (typeof data?.logoData === "string" && data.logoData && !validImage(data.logoData)) return fail("The logo must be a small JPEG, PNG, or WebP.");
	const sql = await getSql();
	if (!await selectStore(sql, "id = $1 and user_id = $2", [storeId, context.userId])) return fail("Shop not found.");
	if ((await sql`select id from stores where slug = ${slug} and id <> ${storeId}`).length > 0) return fail("That shop link is already taken.");
	await sql`
      update stores set
        name = ${name},
        slug = ${slug},
        tagline = ${text(data?.tagline, 140)},
        description = ${text(data?.description, 800)},
        city = ${text(data?.city, 80)},
        whatsapp = ${whatsapp},
        email = ${email},
        status = ${status},
        bank_name = ${text(data?.bankName, 80)},
        account_holder = ${text(data?.accountHolder, 80)},
        account_number = ${text(data?.accountNumber, 30)},
        branch_code = ${text(data?.branchCode, 12)},
        pickup_note = ${text(data?.pickupNote, 240)},
        updated_at = now()
      where id = ${storeId} and user_id = ${context.userId}
    `;
	if (data?.logoData === null) await sql`update stores set logo_data = null where id = ${storeId} and user_id = ${context.userId}`;
	else if (typeof data?.logoData === "string" && data.logoData) await sql`update stores set logo_data = ${data.logoData} where id = ${storeId} and user_id = ${context.userId}`;
	return {
		ok: true,
		data: { id: storeId }
	};
});
var deleteStore_createServerFn_handler = createServerRpc({
	id: "ebea825e68afb6c4acc27f244c209883d574066ff9eda5b76f110a48d57301c3",
	name: "deleteStore",
	filename: "src/lib/sellora/api.ts"
}, (opts) => deleteStore.__executeServer(opts));
var deleteStore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ storeId: text(input?.storeId, 80) })).handler(deleteStore_createServerFn_handler, async ({ context, data }) => {
	if ((await (await getSql())`
      delete from stores where id = ${data.storeId} and user_id = ${context.userId} returning id
    `).length === 0) return fail("Shop not found.");
	return {
		ok: true,
		data: { id: data.storeId }
	};
});
var saveProduct_createServerFn_handler = createServerRpc({
	id: "075a865e246c3a77f14e808b5d6e00e5182cb8fece3d5c21487431d8a2418a46",
	name: "saveProduct",
	filename: "src/lib/sellora/api.ts"
}, (opts) => saveProduct.__executeServer(opts));
var saveProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveProduct_createServerFn_handler, async ({ context, data }) => {
	const storeId = text(data?.storeId, 80);
	const name = text(data?.name, 80);
	const description = text(data?.description, 800);
	const sku = text(data?.sku, 40);
	const status = data?.status === "draft" ? "draft" : "active";
	const price = randsToCents(text(data?.priceRands, 16));
	const compareRaw = text(data?.compareRands, 16);
	const compare = compareRaw ? randsToCents(compareRaw) : null;
	const stock = Math.floor(num(data?.stock));
	if (name.length < 2) return fail("Name the product.");
	if (price == null) return fail("Enter a price in rands, such as 99 or 99.50.");
	if (compareRaw && compare == null) return fail("The compare-at price is not a valid amount.");
	if (stock < 0 || stock > 1e6) return fail("Stock must be zero or more.");
	if (typeof data?.imageData === "string" && data.imageData && !validImage(data.imageData)) return fail("Use a smaller JPEG, PNG, or WebP.");
	const sql = await getSql();
	if (!await selectStore(sql, "id = $1 and user_id = $2", [storeId, context.userId])) return fail("Shop not found.");
	const existingId = text(data?.id, 80);
	if (!existingId) {
		const billing = await ensureSub(sql, context.userId);
		if (num((await sql`select count(*) as n from products where user_id = ${context.userId}`)[0]?.n) >= billing.productLimit) return fail(`${billing.planName} includes ${billing.productLimit} products. Change plan on Billing to add more.`);
	} else if ((await sql`
        select id from products where id = ${existingId} and user_id = ${context.userId} and store_id = ${storeId}
      `).length === 0) return fail("Product not found.");
	const base = slugify(name) || "product";
	let slug = base;
	for (let n = 2; n < 50; n += 1) {
		const clash = await sql`
        select id from products where store_id = ${storeId} and slug = ${slug}
      `;
		if (clash.length === 0 || clash[0]?.id === existingId) break;
		slug = `${base}-${n}`.slice(0, 48);
	}
	const id = existingId || crypto.randomUUID();
	if (!existingId) await sql`
        insert into products (
          id, store_id, user_id, name, slug, description, price_cents, compare_cents, stock, sku, status, image_data
        ) values (
          ${id}, ${storeId}, ${context.userId}, ${name}, ${slug}, ${description}, ${price}, ${compare},
          ${stock}, ${sku}, ${status}, ${typeof data?.imageData === "string" ? data.imageData : null}
        )
      `;
	else {
		await sql`
        update products set
          name = ${name},
          slug = ${slug},
          description = ${description},
          price_cents = ${price},
          compare_cents = ${compare},
          stock = ${stock},
          sku = ${sku},
          status = ${status},
          updated_at = now()
        where id = ${id} and user_id = ${context.userId}
      `;
		if (data?.imageData === null) await sql`
          update products set image_data = null, image_path = null
          where id = ${id} and user_id = ${context.userId}
        `;
		else if (typeof data?.imageData === "string" && data.imageData) await sql`
          update products set image_data = ${data.imageData}, image_path = null
          where id = ${id} and user_id = ${context.userId}
        `;
	}
	return {
		ok: true,
		data: { id }
	};
});
var deleteProduct_createServerFn_handler = createServerRpc({
	id: "f905384ea794fd5c53dda4c881642ec8a8c9841cc6edf171f2464fe4aff34ef9",
	name: "deleteProduct",
	filename: "src/lib/sellora/api.ts"
}, (opts) => deleteProduct.__executeServer(opts));
var deleteProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ productId: text(input?.productId, 80) })).handler(deleteProduct_createServerFn_handler, async ({ context, data }) => {
	if ((await (await getSql())`
      delete from products where id = ${data.productId} and user_id = ${context.userId} returning id
    `).length === 0) return fail("Product not found.");
	return {
		ok: true,
		data: { id: data.productId }
	};
});
var setOrderStatus_createServerFn_handler = createServerRpc({
	id: "377796225f687e07c56f67c83fb220db3cc6778d2184bf3495e00e1c72fe92be",
	name: "setOrderStatus",
	filename: "src/lib/sellora/api.ts"
}, (opts) => setOrderStatus.__executeServer(opts));
var setOrderStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	orderId: text(input?.orderId, 80),
	status: text(input?.status, 20)
})).handler(setOrderStatus_createServerFn_handler, async ({ context, data }) => {
	if (!(/* @__PURE__ */ new Set([
		"new",
		"confirmed",
		"fulfilled",
		"cancelled"
	])).has(data.status)) return fail("Unknown status.");
	const sql = await getSql();
	const order = (await sql`
      select id, status from orders where id = ${data.orderId} and user_id = ${context.userId}
    `)[0];
	if (!order) return fail("Order not found.");
	if (order.status === "cancelled" && data.status !== "cancelled") return fail("A cancelled order stays cancelled so stock is not sold twice.");
	if (order.status !== "cancelled" && data.status === "cancelled") {
		const items = await sql`
        select product_id, qty from order_items where order_id = ${order.id}
      `;
		for (const item of items) {
			if (!item.product_id) continue;
			await sql`
          update products set stock = stock + ${num(item.qty)}, updated_at = now()
          where id = ${item.product_id} and user_id = ${context.userId}
        `;
		}
	}
	await sql`
      update orders set status = ${data.status}
      where id = ${order.id} and user_id = ${context.userId}
    `;
	return {
		ok: true,
		data: { id: order.id }
	};
});
var setPlan_createServerFn_handler = createServerRpc({
	id: "05af58de1ba507eeaa71695b92af357ad227ba23043852bb66c289a1f9bc6668",
	name: "setPlan",
	filename: "src/lib/sellora/api.ts"
}, (opts) => setPlan.__executeServer(opts));
var setPlan = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ plan: text(input?.plan, 20) })).handler(setPlan_createServerFn_handler, async ({ context, data }) => {
	const plan = planById(data.plan);
	if (plan.id !== data.plan) return fail("Unknown plan.");
	const sql = await getSql();
	await ensureSub(sql, context.userId);
	await sql`
      update subscriptions
      set plan = ${plan.id}, status = 'trial', payment_provider = 'test', updated_at = now()
      where user_id = ${context.userId}
    `;
	return {
		ok: true,
		data: await ensureSub(sql, context.userId)
	};
});
//#endregion
export { createStore_createServerFn_handler, deleteProduct_createServerFn_handler, deleteStore_createServerFn_handler, getHome_createServerFn_handler, getPublicOrder_createServerFn_handler, getPublicProduct_createServerFn_handler, getPublicStorefront_createServerFn_handler, getWorkspace_createServerFn_handler, placeOrder_createServerFn_handler, saveProduct_createServerFn_handler, setOrderStatus_createServerFn_handler, setPlan_createServerFn_handler, updateStore_createServerFn_handler };
