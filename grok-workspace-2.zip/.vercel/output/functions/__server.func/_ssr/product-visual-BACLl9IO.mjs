import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-visual-BACLl9IO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductVisual({ name, image, className, labelled = false }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (!image || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid place-items-center bg-muted text-foreground", className),
		"aria-hidden": !labelled,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-4xl",
			children: name.trim().charAt(0).toUpperCase() || "S"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: image,
		alt: labelled ? name : "",
		className: cn("h-full w-full object-cover", className),
		onError: () => setFailed(true)
	});
}
//#endregion
export { ProductVisual as t };
