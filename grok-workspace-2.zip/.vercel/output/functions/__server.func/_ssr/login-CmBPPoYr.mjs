import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as GROK_PROVIDERS } from "./server-UOA1p4Xi.mjs";
import { t as Button } from "./button-DfBJgGpx.mjs";
import { t as Input } from "./input-r-EVbXg8.mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { t as Mark } from "./site-QmrpY1WO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-CmBPPoYr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BEARER_KEY = "grok-auth.bearer-token";
function rememberToken(response) {
	const token = response.headers.get("set-auth-token");
	if (!token) return;
	try {
		sessionStorage.setItem(BEARER_KEY, token);
	} catch {}
}
function LoginPage() {
	const [mode, setMode] = (0, import_react.useState)("up");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		if (password.length < 8) {
			setError("Use at least 8 characters.");
			return;
		}
		setPending(true);
		try {
			if (mode === "up") {
				if (name.trim().length < 2) {
					setError("Add the name of the person who will run the shop.");
					setPending(false);
					return;
				}
				const result = await authClient.signUp.email({
					name: name.trim(),
					email: email.trim(),
					password,
					callbackURL: "/dashboard",
					fetchOptions: { onSuccess: (ctx) => rememberToken(ctx.response) }
				});
				if (result.error) {
					setError(result.error.message ?? "Could not create the account.");
					setPending(false);
					return;
				}
			} else {
				const result = await authClient.signIn.email({
					email: email.trim(),
					password,
					callbackURL: "/dashboard",
					fetchOptions: { onSuccess: (ctx) => rememberToken(ctx.response) }
				});
				if (result.error) {
					setError(result.error.message ?? "Those details did not match.");
					setPending(false);
					return;
				}
			}
			window.location.assign("/dashboard");
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Sign-in failed.");
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "grid min-h-screen bg-background lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col px-5 py-6 sm:px-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2 text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl",
					children: "Sellora"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-sm flex-1 flex-col justify-center py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl",
						children: mode === "up" ? "Open your workspace" : "Welcome back"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: mode === "up" ? "Create the account that will own your stores. You can invite a card later." : "Sign in to manage products, stock, and orders."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-8 space-y-4",
						onSubmit,
						children: [
							mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["Your name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "mt-1.5",
									value: name,
									onChange: (event) => setName(event.target.value),
									autoComplete: "name",
									required: true
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "mt-1.5",
									type: "email",
									value: email,
									onChange: (event) => setEmail(event.target.value),
									autoComplete: "email",
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "mt-1.5",
									type: "password",
									value: password,
									onChange: (event) => setPassword(event.target.value),
									autoComplete: mode === "up" ? "new-password" : "current-password",
									required: true,
									minLength: 8
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-danger",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full",
								size: "lg",
								disabled: pending,
								children: pending ? "Please wait…" : mode === "up" ? "Create account" : "Sign in"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-sm text-muted-foreground underline",
								onClick: () => {
									setMode(mode === "up" ? "in" : "up");
									setError("");
								},
								children: mode === "up" ? "I already have an account" : "Create an account"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Or continue with"
						}), GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							className: "w-full",
							onClick: () => {
								setError("");
								signIn(provider.providerId, { callbackURL: "/dashboard" }).catch((caught) => {
									setError(caught instanceof Error ? caught.message : "Sign-in failed.");
								});
							},
							children: ["Continue with ", provider.label]
						}, provider.providerId))]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden border-l border-border bg-card lg:flex lg:flex-col lg:justify-end lg:p-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md font-display text-4xl",
				children: "A store link you can send on WhatsApp tonight."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-sm text-muted-foreground",
				children: "Products, stock, and orders stay with your business. Powered by WebDev SA."
			})]
		})]
	});
}
//#endregion
export { LoginPage as component };
