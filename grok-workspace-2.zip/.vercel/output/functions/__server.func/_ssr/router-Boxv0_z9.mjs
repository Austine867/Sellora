import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, X as require_react, _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { L as string, N as number, P as object, R as union, j as literal } from "../_libs/@better-auth/core+[...].mjs";
import { i as getSql, t as authMiddleware } from "./middleware-B1lhXKUH.mjs";
import { n as auth } from "./server-UOA1p4Xi.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-JDaBjoZT.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function text(value, max) {
	if (typeof value !== "string") return "";
	return value.trim().slice(0, max);
}
var getPublicStorefront = createServerFn({ method: "GET" }).validator((input) => ({ slug: text(input?.slug, 40) })).handler(createSsrRpc("54507828ad7e9b98dcfdcc2a8df75fce11e87751c2fc64218b3248d115ff584d"));
var getPublicProduct = createServerFn({ method: "GET" }).validator((input) => ({
	slug: text(input?.slug, 40),
	productSlug: text(input?.productSlug, 60)
})).handler(createSsrRpc("9d6c9d8e5a70bf6302fe7f828084fd7f75be822da89e3c4ceed4f34bd5dd24c7"));
var getPublicOrder = createServerFn({ method: "GET" }).validator((input) => ({
	slug: text(input?.slug, 40),
	number: text(input?.number, 20).toUpperCase()
})).handler(createSsrRpc("df102c9c122d304de826b910b467a1851f41538587d9b19f4397b2178b25c633"));
var placeOrder = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("18bb235a40c1f79cd05282c41f2a796e65cbf4316a7ab74ada11517e252e3dc5"));
var getHome = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("0a0ffa222e8ab9ebd82e3c8b6d1cc7979efb589f5a03d52b6391f2710af51f9a"));
var createStore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("9863935f911ef2825e08cf2043798dc05083b2a86afb07916b980bf26582e948"));
var getWorkspace = createServerFn({ method: "GET" }).middleware([authMiddleware]).validator((input) => ({ storeId: text(input?.storeId, 80) })).handler(createSsrRpc("598785791b506d769a2cb8544a11d492a4c3bd2356c9712ae1d95b3f2e65aa48"));
var updateStore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("27488c6acdab84f6c449d7fc482b50aeff2a86fce7dc39b5efe332a490765785"));
var deleteStore = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ storeId: text(input?.storeId, 80) })).handler(createSsrRpc("ebea825e68afb6c4acc27f244c209883d574066ff9eda5b76f110a48d57301c3"));
var saveProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("075a865e246c3a77f14e808b5d6e00e5182cb8fece3d5c21487431d8a2418a46"));
var deleteProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ productId: text(input?.productId, 80) })).handler(createSsrRpc("f905384ea794fd5c53dda4c881642ec8a8c9841cc6edf171f2464fe4aff34ef9"));
var setOrderStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	orderId: text(input?.orderId, 80),
	status: text(input?.status, 20)
})).handler(createSsrRpc("377796225f687e07c56f67c83fb220db3cc6778d2184bf3495e00e1c72fe92be"));
var setPlan = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({ plan: text(input?.plan, 20) })).handler(createSsrRpc("05af58de1ba507eeaa71695b92af357ad227ba23043852bb66c289a1f9bc6668"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-Boxv0_z9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-danger",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted-foreground",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-GswgEOE_.css";
var APP_NAME = "Sellora";
var Route$14 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Sellora helps South African businesses run an online shop — products, stock, orders, and a link you can share. From R99 a month. Powered by WebDev SA."
			},
			{
				name: "theme-color",
				content: "#f4f2ec"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,560&family=Outfit:wght@400;500;600&display=swap"
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-screen bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$10 = () => import("./routes-DhPj1PB8.mjs");
var Route$13 = createFileRoute("/")({
	loader: async () => {
		try {
			return await getPublicStorefront({ data: { slug: "cedar-and-salt" } });
		} catch {
			return null;
		}
	},
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./dashboard-CHfCGFfj.mjs");
var Route$12 = createFileRoute("/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./login-CmBPPoYr.mjs");
var Route$11 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./dashboard-BOMvG_5a.mjs");
var Route$10 = createFileRoute("/dashboard/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./billing-Dp7TPebK.mjs");
var Route$9 = createFileRoute("/dashboard/billing")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./new-D1JgK-8h.mjs");
var Route$8 = createFileRoute("/dashboard/new")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var Route$7 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var $$splitComponentImporter$4 = () => import("../_storeId-DicU03xe.mjs");
var Route$6 = createFileRoute("/dashboard/stores/$storeId")({
	validateSearch: (search) => {
		const tab = search.tab === "orders" || search.tab === "settings" ? search.tab : "products";
		const edit = typeof search.edit === "string" && search.edit.length > 0 ? search.edit : void 0;
		return edit ? {
			tab,
			edit
		} : { tab };
	},
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_slug-D2DreXzu.mjs");
var Route$5 = createFileRoute("/s/$slug/")({
	loader: async ({ params }) => getPublicStorefront({ data: { slug: params.slug } }),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData?.store ? `${loaderData.store.name} · Sellora` : "Shop · Sellora" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./checkout-ByLzMVU7.mjs");
var Route$4 = createFileRoute("/s/$slug/checkout")({
	loader: ({ params }) => getPublicStorefront({ data: { slug: params.slug } }),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData?.store ? `Checkout · ${loaderData.store.name}` : "Checkout · Sellora" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
function imageResponse(data) {
	if (!data) return new Response("Not found", { status: 404 });
	const comma = data.indexOf(",");
	if (comma < 0 || !data.startsWith("data:image/")) return new Response("Not found", { status: 404 });
	const mime = data.slice(5, comma).split(";")[0]?.toLowerCase() ?? "";
	if (mime !== "image/jpeg" && mime !== "image/png" && mime !== "image/webp") return new Response("Not found", { status: 404 });
	const bytes = Buffer.from(data.slice(comma + 1), "base64");
	return new Response(bytes, { headers: {
		"Content-Type": mime,
		"Cache-Control": "public, max-age=86400"
	} });
}
var Route$3 = createFileRoute("/api/media/product/$productId")({ server: { handlers: { GET: async ({ params }) => {
	return imageResponse((await (await getSql())`
          select image_data from products where id = ${params.productId}
        `)[0]?.image_data ?? null);
} } } });
var Route$2 = createFileRoute("/api/media/store/$storeId")({ server: { handlers: { GET: async ({ params }) => {
	const data = (await (await getSql())`
          select logo_data from stores where id = ${params.storeId}
        `)[0]?.logo_data ?? null;
	if (!data) return new Response("Not found", { status: 404 });
	const comma = data.indexOf(",");
	if (comma < 0 || !data.startsWith("data:image/")) return new Response("Not found", { status: 404 });
	const mime = data.slice(5, comma).split(";")[0]?.toLowerCase() ?? "";
	if (mime !== "image/jpeg" && mime !== "image/png" && mime !== "image/webp") return new Response("Not found", { status: 404 });
	const bytes = Buffer.from(data.slice(comma + 1), "base64");
	return new Response(bytes, { headers: {
		"Content-Type": mime,
		"Cache-Control": "public, max-age=86400"
	} });
} } } });
var $$splitComponentImporter$1 = () => import("../_number-CZovUqpj.mjs");
var Route$1 = createFileRoute("/s/$slug/order/$number")({
	loader: ({ params }) => getPublicOrder({ data: {
		slug: params.slug,
		number: params.number
	} }),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData ? `Order ${loaderData.number}` : "Order · Sellora" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_productSlug-D4tPQwBW.mjs");
var Route = createFileRoute("/s/$slug/p/$productSlug")({
	loader: ({ params }) => getPublicProduct({ data: {
		slug: params.slug,
		productSlug: params.productSlug
	} }),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData?.product ? `${loaderData.product.name} · ${loaderData.store.name}` : "Product · Sellora" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var DashboardRoute = Route$12.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => Route$14
});
var LoginRoute = Route$11.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$14
});
var DashboardIndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => DashboardRoute
});
var DashboardBillingRoute = Route$9.update({
	id: "/billing",
	path: "/billing",
	getParentRoute: () => DashboardRoute
});
var DashboardNewRoute = Route$8.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => DashboardRoute
});
var ApiAuthSplatRoute = Route$7.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$14
});
var DashboardStoresStoreIdRoute = Route$6.update({
	id: "/stores/$storeId",
	path: "/stores/$storeId",
	getParentRoute: () => DashboardRoute
});
var SSlugIndexRoute = Route$5.update({
	id: "/s/$slug/",
	path: "/s/$slug/",
	getParentRoute: () => Route$14
});
var SSlugCheckoutRoute = Route$4.update({
	id: "/s/$slug/checkout",
	path: "/s/$slug/checkout",
	getParentRoute: () => Route$14
});
var ApiMediaProductProductIdRoute = Route$3.update({
	id: "/api/media/product/$productId",
	path: "/api/media/product/$productId",
	getParentRoute: () => Route$14
});
var ApiMediaStoreStoreIdRoute = Route$2.update({
	id: "/api/media/store/$storeId",
	path: "/api/media/store/$storeId",
	getParentRoute: () => Route$14
});
var SSlugOrderNumberRoute = Route$1.update({
	id: "/s/$slug/order/$number",
	path: "/s/$slug/order/$number",
	getParentRoute: () => Route$14
});
var SSlugPProductSlugRoute = Route.update({
	id: "/s/$slug/p/$productSlug",
	path: "/s/$slug/p/$productSlug",
	getParentRoute: () => Route$14
});
var DashboardRouteChildren = {
	DashboardBillingRoute,
	DashboardNewRoute,
	DashboardIndexRoute,
	DashboardStoresStoreIdRoute
};
var rootRouteChildren = {
	IndexRoute,
	DashboardRoute: DashboardRoute._addFileChildren(DashboardRouteChildren),
	LoginRoute,
	ApiAuthSplatRoute,
	SSlugCheckoutRoute,
	SSlugIndexRoute,
	ApiMediaProductProductIdRoute,
	ApiMediaStoreStoreIdRoute,
	SSlugOrderNumberRoute,
	SSlugPProductSlugRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: NotFound
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-background px-6 text-center text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl text-foreground",
					children: "This page is not on the shelf."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: "The link may be old, or the shop may have been unpublished."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
					children: "Back to Sellora"
				})
			]
		})
	});
}
//#endregion
export { updateStore as _, Route$5 as a, createStore as c, getHome as d, getWorkspace as f, setPlan as g, setOrderStatus as h, Route$4 as i, deleteProduct as l, saveProduct as m, Route as n, Route$6 as o, placeOrder as p, Route$1 as r, Route$13 as s, router_exports as t, deleteStore as u };
