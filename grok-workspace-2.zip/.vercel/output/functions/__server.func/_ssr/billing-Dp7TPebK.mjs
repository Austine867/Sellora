import { o as __toESM } from "../_runtime.mjs";
import { n as formatWhen } from "./format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, X as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as getHome, g as setPlan } from "./router-Boxv0_z9.mjs";
import { t as Button } from "./button-DfBJgGpx.mjs";
import { t as PLANS } from "./plans-C-X31toq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-Dp7TPebK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BillingPage() {
	const [billing, setBilling] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getHome().then((home) => {
			if (!cancelled) setBilling(home.billing);
		}).catch((caught) => {
			if (!cancelled) setError(caught instanceof Error ? caught.message : "Could not load billing.");
		});
		return () => {
			cancelled = true;
		};
	}, []);
	async function choose(plan) {
		setPending(plan);
		setError("");
		const result = await setPlan({ data: { plan } });
		setPending(null);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		setBilling(result.data);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl",
			children: "Billing"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-xl text-muted-foreground",
			children: "Plans start at R99 a month. Payments run in test mode: choosing a plan sets your limits and does not charge a card. When PayFast or Yoco is connected, a webhook will confirm the payment before a plan is marked paid."
		}),
		billing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm",
			children: [
				"Current plan: ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: billing.planName
				}),
				billing.trialEndsAt ? ` · trial noted until ${formatWhen(billing.trialEndsAt)}` : "",
				" · ",
				"provider: ",
				billing.paymentProvider
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-8 w-64 animate-pulse rounded-md bg-muted" }),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid gap-4 lg:grid-cols-3",
			children: PLANS.map((plan) => {
				const current = billing?.plan === plan.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex flex-col rounded-2xl bg-card p-6 ring-1 ring-foreground/10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: plan.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 font-display text-4xl tabular-nums",
							children: [
								"R",
								plan.priceZar,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-sans text-base text-muted-foreground",
									children: " / month"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: plan.blurb
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 flex-1 space-y-2 text-sm",
							children: plan.features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: feature }, feature))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-6",
							variant: current ? "secondary" : "primary",
							disabled: current || pending !== null,
							onClick: () => choose(plan.id),
							children: current ? "Current plan" : pending === plan.id ? "Saving…" : "Use this plan"
						})
					]
				}, plan.id);
			})
		})
	] });
}
//#endregion
export { BillingPage as component };
