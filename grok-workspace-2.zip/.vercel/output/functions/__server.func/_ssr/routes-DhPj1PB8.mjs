import { r as formatZar } from "./format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Route$13 } from "./router-Boxv0_z9.mjs";
import { t as ProductVisual } from "./product-visual-BACLl9IO.mjs";
import { t as PLANS } from "./plans-C-X31toq.mjs";
import { n as SiteFooter, r as SiteHeader } from "./site-QmrpY1WO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DhPj1PB8.js
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		n: "01",
		title: "Open a shop",
		body: "Register the business, name the store, and publish a link that is yours — not a marketplace listing."
	},
	{
		n: "02",
		title: "Add what you sell",
		body: "Upload a photo, set a rand price, and keep stock honest. Drafts stay hidden until you are ready."
	},
	{
		n: "03",
		title: "Take the order",
		body: "Customers check out with EFT or collection. You confirm, pack, and mark it fulfilled."
	}
];
function Home() {
	const sample = Route$13.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:py-20 lg:grid-cols-[1.2fr_0.8fr] lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-muted-foreground",
							children: "For South African makers and small businesses"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-xl font-display text-5xl leading-tight text-foreground sm:text-6xl",
							children: "Your shop, under your own link."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-lg text-lg text-muted-foreground",
							children: "Sellora is where you put products, stock, and customer orders — then send people a link. From R99 a month. No marketplace taking the relationship."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "inline-flex h-12 items-center justify-center rounded-lg bg-primary px-5 text-sm font-medium text-primary-foreground",
								children: "Start a store"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/s/$slug",
								params: { slug: "cedar-and-salt" },
								className: "inline-flex h-12 items-center justify-center rounded-lg bg-secondary px-5 text-sm font-medium text-secondary-foreground",
								children: "View a live shop"
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "rounded-2xl bg-card p-2 ring-1 ring-foreground/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-secondary p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
									children: "A shop link"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-3xl",
									children: "sellora / cedar-and-salt"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-6 grid grid-cols-3 gap-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted-foreground",
											children: "From"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-medium tabular-nums",
											children: "R99"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted-foreground",
											children: "Currency"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-medium",
											children: "ZAR"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted-foreground",
											children: "Checkout"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-medium",
											children: "EFT"
										})] })
									]
								})
							]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "how",
					className: "border-t border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:grid-cols-3",
						children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-muted-foreground",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted-foreground",
								children: step.body
							})
						] }, step.n))
					})
				}),
				sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-t border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-5 py-14",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col justify-between gap-3 sm:flex-row sm:items-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: sample.store.city
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 font-display text-4xl",
									children: sample.store.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 max-w-lg text-muted-foreground",
									children: sample.store.tagline
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/s/$slug",
								params: { slug: sample.store.slug },
								className: "text-sm font-medium underline",
								children: "Open the shop"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4",
							children: sample.products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/s/$slug/p/$productSlug",
								params: {
									slug: sample.store.slug,
									productSlug: product.slug
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "overflow-hidden rounded-xl bg-card ring-1 ring-foreground/10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
											name: product.name,
											image: product.image,
											className: "aspect-square"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm font-medium",
										children: product.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm tabular-nums text-muted-foreground",
										children: formatZar(product.priceCents)
									})
								]
							}) }, product.id))
						})]
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "pricing",
					className: "border-t border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-5 py-14",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-4xl",
								children: "Monthly, from R99."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-xl text-muted-foreground",
								children: "Pick a plan when you open the workspace. Card payments are not connected yet — test mode will not charge you. PayFast or Yoco can sit on the same plan limits later."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 grid gap-4 lg:grid-cols-3",
								children: PLANS.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: plan.id === "starter" ? "rounded-2xl bg-card p-6 ring-2 ring-foreground" : "rounded-2xl bg-card p-6 ring-1 ring-foreground/10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: plan.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-3 font-display text-4xl tabular-nums",
											children: [
												"R",
												plan.priceZar,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-sans text-base text-muted-foreground",
													children: " / month"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-muted-foreground",
											children: plan.blurb
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-5 space-y-2 text-sm",
											children: plan.features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: feature }, feature))
										})
									]
								}, plan.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "mt-8 inline-flex h-12 items-center rounded-lg bg-primary px-5 text-sm font-medium text-primary-foreground",
								children: "Create an account"
							})
						]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
