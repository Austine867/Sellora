import { o as __toESM } from "../_runtime.mjs";
import { r as formatZar } from "./format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Route$4, p as placeOrder } from "./router-Boxv0_z9.mjs";
import { i as useCart, n as StoreChrome, r as cartTotal, t as MissingShop } from "./store-chrome-DWr1DRWO.mjs";
import { t as Button } from "./button-DfBJgGpx.mjs";
import { t as ProductVisual } from "./product-visual-BACLl9IO.mjs";
import { t as Input } from "./input-r-EVbXg8.mjs";
import { t as Textarea } from "./textarea-CUz23fNo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-ByLzMVU7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CheckoutPage() {
	const data = Route$4.useLoaderData();
	const navigate = useNavigate();
	const slug = data?.store.slug ?? "";
	const items = useCart((state) => state.carts[slug]);
	const setQty = useCart((state) => state.setQty);
	const clear = useCart((state) => state.clear);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("eft");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingShop, {});
	const { store } = data;
	const lines = ready ? items ?? [] : [];
	const total = cartTotal(lines);
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError("");
		const result = await placeOrder({ data: {
			slug: store.slug,
			items: lines.map((line) => ({
				productId: line.productId,
				qty: line.qty
			})),
			customer: {
				name,
				email,
				phone,
				city,
				address,
				notes
			},
			paymentMethod: method
		} });
		setPending(false);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		clear(store.slug);
		navigate({
			to: "/s/$slug/order/$number",
			params: {
				slug: store.slug,
				number: result.data.number
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StoreChrome, {
		store,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Checkout"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "The shop confirms the price and stock when you place the order. Card payments are not taken here yet."
			}),
			lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your bag is empty." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/s/$slug",
					params: { slug: store.slug },
					className: "mt-4 inline-block text-sm underline",
					children: "Continue browsing"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-8 lg:grid-cols-[1fr_320px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-4",
					onSubmit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1.5",
								value: name,
								onChange: (event) => setName(event.target.value),
								required: true,
								autoComplete: "name"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1.5",
								type: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value),
								required: true,
								autoComplete: "email"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Mobile", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1.5",
								value: phone,
								onChange: (event) => setPhone(event.target.value),
								autoComplete: "tel"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1.5",
								value: city,
								onChange: (event) => setCity(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Address or collection note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								className: "mt-1.5",
								value: address,
								onChange: (event) => setAddress(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Note to the shop", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								className: "mt-1.5",
								value: notes,
								onChange: (event) => setNotes(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
									className: "text-sm font-medium",
									children: "How you will pay"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-h-11 items-center gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "pay",
										checked: method === "eft",
										onChange: () => setMethod("eft")
									}), "EFT — the shop’s banking details are on the confirmation"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-h-11 items-center gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										name: "pay",
										checked: method === "collection",
										onChange: () => setMethod("collection")
									}), "Pay on collection"]
								})
							]
						}),
						method === "eft" && store.bank ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-secondary p-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: "Pay to"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									children: store.bank.bankName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: store.bank.accountHolder }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "tabular-nums",
									children: store.bank.accountNumber
								}),
								store.bank.branchCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Branch ", store.bank.branchCode] }) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-muted-foreground",
									children: "Use your order number as the payment reference."
								})
							]
						}) : null,
						method === "collection" && store.pickupNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-xl bg-secondary p-4 text-sm",
							children: store.pickupNote
						}) : null,
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							disabled: pending,
							children: pending ? "Placing order…" : `Place order · ${formatZar(total)}`
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "h-fit rounded-2xl bg-card p-4 ring-1 ring-foreground/10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Bag"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-4",
							children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-16 shrink-0 overflow-hidden rounded-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductVisual, {
										name: line.name,
										image: line.image,
										className: "size-16"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: line.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm tabular-nums text-muted-foreground",
											children: formatZar(line.priceCents)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "inline-flex size-8 items-center justify-center rounded-md bg-secondary",
													onClick: () => setQty(store.slug, line.productId, line.qty - 1),
													"aria-label": "Decrease quantity",
													children: "−"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-6 text-center text-sm tabular-nums",
													children: line.qty
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "inline-flex size-8 items-center justify-center rounded-md bg-secondary",
													onClick: () => setQty(store.slug, line.productId, line.qty + 1),
													"aria-label": "Increase quantity",
													children: "+"
												})
											]
										})
									]
								})]
							}, line.productId))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 flex justify-between text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatZar(total)
							})]
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { CheckoutPage as component };
