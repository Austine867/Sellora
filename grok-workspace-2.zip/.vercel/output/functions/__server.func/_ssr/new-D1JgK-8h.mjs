import { o as __toESM } from "../_runtime.mjs";
import { c as slugify } from "./format-B_5Dlkxi.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as createStore } from "./router-Boxv0_z9.mjs";
import { t as Button } from "./button-DfBJgGpx.mjs";
import { t as Input } from "./input-r-EVbXg8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/new-D1JgK-8h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewStorePage() {
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [slug, setSlug] = (0, import_react.useState)("");
	const [slugTouched, setSlugTouched] = (0, import_react.useState)(false);
	const [city, setCity] = (0, import_react.useState)("");
	const [tagline, setTagline] = (0, import_react.useState)("");
	const [publish, setPublish] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	async function onSubmit(event) {
		event.preventDefault();
		setPending(true);
		setError("");
		const result = await createStore({ data: {
			name,
			slug: slug || slugify(name),
			city,
			tagline,
			publish
		} });
		setPending(false);
		if (!result.ok) {
			setError(result.message);
			return;
		}
		navigate({
			to: "/dashboard/stores/$storeId",
			params: { storeId: result.data.id },
			search: {
				tab: "products",
				edit: "new"
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dashboard",
				className: "text-sm text-muted-foreground",
				children: "Back to stores"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl",
				children: "New store"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted-foreground",
				children: "This becomes the public link customers open."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 space-y-4",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Store name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "mt-1.5",
							value: name,
							onChange: (event) => {
								setName(event.target.value);
								if (!slugTouched) setSlug(slugify(event.target.value));
							},
							required: true,
							placeholder: "Harbour Goods"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Link", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1.5 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted-foreground",
								children: "/s/"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: slug,
								onChange: (event) => {
									setSlugTouched(true);
									setSlug(slugify(event.target.value));
								},
								required: true,
								placeholder: "harbour-goods"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "mt-1.5",
							value: city,
							onChange: (event) => setCity(event.target.value),
							placeholder: "Durban"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Short line", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "mt-1.5",
							value: tagline,
							onChange: (event) => setTagline(event.target.value),
							placeholder: "What you sell, in one sentence"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: publish,
							onChange: (event) => setPublish(event.target.checked),
							className: "size-4"
						}), "Publish now, so the link works immediately"]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: pending,
						children: pending ? "Creating…" : "Create store"
					})
				]
			})
		]
	});
}
//#endregion
export { NewStorePage as component };
